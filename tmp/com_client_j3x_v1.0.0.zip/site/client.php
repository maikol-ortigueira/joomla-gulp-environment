<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */

defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\MVC\Controller\BaseController;

// Include dependancies
jimport('joomla.application.component.controller');

JLoader::registerPrefix('Client', JPATH_COMPONENT);
JLoader::register('ClientController', JPATH_COMPONENT . '/controller.php');

// Execute the task.
$controller = BaseController::getInstance('Client');
$controller->execute(Factory::getApplication()->input->get('task'));
$controller->redirect();
