<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;
/**
 * Content Component Category Tree
 *
 * @since  1.6
 */
class ClientCategories extends \Joomla\CMS\Categories\Categories
{
    /**
     * Class constructor
     *
     * @param   array  $options  Array of options
     *
     * @since   11.1
     */
    public function __construct($options = array())
    {
        $options['table'] = '#__clients';
        $options['extension'] = 'com_client';

        parent::__construct($options);
    }
}
