<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
defined('_JEXEC') or die;

JLoader::register('ClientHelper', JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_client' . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'client.php');

use \Joomla\CMS\Factory;
use \Joomla\CMS\MVC\Model\BaseDatabaseModel;
use \Joomla\Utilities\ArrayHelper;

/**
 * Class ClientFrontendHelper
 *
 * @since  1.6
 */
class ClientHelpersClient
{
	/**
	* Get category name using category ID
	* @param integer $category_id Category ID
	* @return mixed category name if the category was found, null otherwise
	*/
	public static function getCategoryNameByCategoryId($category_id) {
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query
			->select('title')
			->from('#__categories')
			->where('id = ' . intval($category_id));

		$db->setQuery($query);
		return $db->loadResult();
	}
	/**
	 * Get an instance of the named model
	 *
	 * @param   string  $name  Model name
	 *
	 * @return null|object
	 */
	public static function getModel($name)
	{
		$model = null;

		// If the file exists, let's
		if (file_exists(JPATH_SITE . '/components/com_client/models/' . strtolower($name) . '.php'))
		{
			require_once JPATH_SITE . '/components/com_client/models/' . strtolower($name) . '.php';
			$model = BaseDatabaseModel::getInstance($name, 'ClientModel');
		}

		return $model;
	}

	/**
	 * Gets the files attached to an item
	 *
	 * @param   int     $pk     The item's id
	 *
	 * @param   string  $table  The table's name
	 *
	 * @param   string  $field  The field's name
	 *
	 * @return  array  The files
	 */
	public static function getFiles($pk, $table, $field)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$query
			->select($field)
			->from($table)
			->where('id = ' . (int) $pk);

		$db->setQuery($query);

		return explode(',', $db->loadResult());
	}

    /**
     * Gets the edit permission for an user
     *
     * @param   mixed  $item  The item
     *
     * @return  bool
     */
    public static function canUserEdit($item)
    {
        $permission = false;
        $user       = Factory::getUser();

        if ($user->authorise('core.edit', 'com_client'))
        {
            $permission = true;
        }
        else
        {
            if (isset($item->created_by))
            {
                if ($user->authorise('core.edit.own', 'com_client') && $item->created_by == $user->id)
                {
                    $permission = true;
                }
            }
            else
            {
                $permission = true;
            }
        }

        return $permission;
    }

	public static function getInvoiceData($item, $params)
	{
		$item->type = 'invoice';

		// Cambio el nombre de la variable de lineas para que el layout sea estandard
		$item->translation_lines = $item->invoice_translation_lines;
		unset($item->invoice_translation_lines);

		// Cambio el nombre de la variable de número de factura para que el layout sea estandard
		$item->document_num = $item->invoice_num;
		unset($item->invoice_num);

		// Cambio el nombre de la variable de fecha de factura para que el layout sea estandard
		$item->document_date = $item->invoice_date;
		unset($item->invoice_date);

		return self::getData($item, $params);
	}

	public static function getQuoteData($item, $params)
	{
		$item->type = 'quote';

		// Cambio el nombre de la variable de lineas para que el layout sea estandard
		$item->translation_lines = $item->quote_translation_lines;
		unset($item->quote_translation_lines);

		// Cambio el nombre de la variable de número de factura para que el layout sea estandard
		$item->document_num = $item->quote_num;
		unset($item->quote_num);

		// Cambio el nombre de la variable de fecha de factura para que el layout sea estandard
		$item->document_date = $item->quote_date;
		unset($item->quote_date);

		return self::getData($item, $params);
	}

	public static function getData($item, $params)
	{

		$data = array();

		foreach ($item as $key => $value) {
			$data[$key] = $value;
		}

		$data['to_state'] = ClientHelper::getProvincia($data['to_state']);

		// Calcular los totales por cada linea de factura/presupuesto
		self::getLineTotals($data);
		self::getLineLanguage($data);

		$data['iva'] = $params->get('iva');
		$data['from_name'] = $params->get('from_name');
		$data['from_address_1'] = $params->get('from_address_1');
		$data['from_address_2'] = $params->get('from_address_2');
		$data['from_zipcode'] = $params->get('from_zipcode');
		$data['from_city'] = $params->get('from_city');
		$data['from_state'] = $params->get('from_state');
		$data['from_country'] = $params->get('from_country');
		$data['from_email'] = $params->get('from_email');
		$data['from_num'] = $params->get('from_num');
		$data['company_logo'] = $params->get('company_logo');

		$data = ArrayHelper::toObject($data, 'JObject');

		return $data;
	}

	public static function getLineTotals(&$data)
	{
		foreach ($data['translation_lines'] as $key => $value)
		{
			$value->total = (int)$value->amount * floatval($value->price);
		}
		return $data;
	}

	public static function getLineLanguage(&$data)
	{

		foreach ($data['translation_lines'] as $key => $value) {
			$value->from_tags = ClientHelper::getFieldValue('#__client_languages', 'tag_from', $value->languages);
			$value->to_tags = ClientHelper::getFieldValue('#__client_languages', 'tag_to', $value->languages);
			$from = substr($value->from_tags, 0,2);
			$to = substr($value->to_tags, 0,2);

			$value->from_language = ClientHelper::getFieldValue('#__paises_idiomas_idiomas', 'idioma', $from, 'etiqueta');
			$value->to_language = ClientHelper::getFieldValue('#__paises_idiomas_idiomas', 'idioma', $to, 'etiqueta');

		}
	}

	public static function formatCurrency($value)
	{
		$value = ClientHelper::formatCurrency($value);

		return $value;
	}

}
