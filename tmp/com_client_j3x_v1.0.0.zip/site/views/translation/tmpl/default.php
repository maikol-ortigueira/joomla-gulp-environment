<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

$canEdit = JFactory::getUser()->authorise('core.edit', 'com_client.' . $this->item->id);

if (!$canEdit && JFactory::getUser()->authorise('core.edit.own', 'com_client' . $this->item->id))
{
	$canEdit = JFactory::getUser()->id == $this->item->created_by;
}
?>

<div class="item_fields">

	<table class="table">
		

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_TRANSLATION_UPLOADED_FILE'); ?></th>
			<td>
			<?php
			foreach ((array) $this->item->uploaded_file as $singleFile) : 
				if (!is_array($singleFile)) : 
					$uploadPath = 'translations' . DIRECTORY_SEPARATOR . $singleFile;
					 echo '<a href="' . JRoute::_(JUri::root() . $uploadPath, false) . '" target="_blank">' . $singleFile . '</a> ';
				endif;
			endforeach;
		?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_TRANSLATION_CLIENT_ID'); ?></th>
			<td><?php echo $this->item->client_id; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_TRANSLATION_WORDS'); ?></th>
			<td><?php echo $this->item->words; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_TRANSLATION_QUOTE_ID'); ?></th>
			<td><?php echo $this->item->quote_id; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_TRANSLATION_ORIGIN_FILENAME'); ?></th>
			<td><?php echo $this->item->origin_filename; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_TRANSLATION_FILENAME'); ?></th>
			<td><?php echo $this->item->filename; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_TRANSLATION_UPLOADED_DATE'); ?></th>
			<td><?php echo $this->item->uploaded_date; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_TRANSLATION_LINES'); ?></th>
			<td><?php echo $this->item->lines; ?></td>
		</tr>

	</table>

</div>

<?php if($canEdit && $this->item->checked_out == 0): ?>

	<a class="btn" href="<?php echo JRoute::_('index.php?option=com_client&task=translation.edit&id='.$this->item->id); ?>"><?php echo JText::_("COM_ORTRANSLATOR_EDIT_ITEM"); ?></a>

<?php endif; ?>

<?php if (JFactory::getUser()->authorise('core.delete','com_client.translation.'.$this->item->id)) : ?>

	<a class="btn btn-danger" href="#deleteModal" role="button" data-toggle="modal">
		<?php echo JText::_("COM_ORTRANSLATOR_DELETE_ITEM"); ?>
	</a>

	<div id="deleteModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="deleteModal" aria-hidden="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			<h3><?php echo JText::_('COM_ORTRANSLATOR_DELETE_ITEM'); ?></h3>
		</div>
		<div class="modal-body">
			<p><?php echo JText::sprintf('COM_ORTRANSLATOR_DELETE_CONFIRM', $this->item->id); ?></p>
		</div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal">Close</button>
			<a href="<?php echo JRoute::_('index.php?option=com_client&task=translation.remove&id=' . $this->item->id, false, 2); ?>" class="btn btn-danger">
				<?php echo JText::_('COM_ORTRANSLATOR_DELETE_ITEM'); ?>
			</a>
		</div>
	</div>

<?php endif; ?>