<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;

$document = Factory::getDocument();
$document->addStyleSheet(Uri::root() . 'media/com_client/css/pdf.css');
$document->addStyleDeclaration('body{
	background: rgb(204, 204, 204);
}');

$canEdit = JFactory::getUser()->authorise('core.edit', 'com_client.' . $this->item->id);

if (!$canEdit && JFactory::getUser()->authorise('core.edit.own', 'com_client' . $this->item->id))
{
	$canEdit = JFactory::getUser()->id == $this->item->created_by;
}

$html = $layout = new JLayoutFile('invoice-quote', null, array('client' =>1));
$data = ClientHelpersClient::getInvoiceData($this->item, $this->params);

$data->company_logo = Uri::root() . $data->company_logo;
		/****************** ACUÉRDATE DE BORRAR ESTAS LINEAS ******************/
		//echo '<pre>'; print_r($data['logo']);echo '</pre>';jexit();
?>

<div class="a4">
	<div class="pdf">
		<?php echo $layout->render($data); ?>
		<a class="uk-button uk-button-danger uk-button-small uk-float-right" href="<?php echo JRoute::_('index.php?option=com_client&view=invoice&format=pdf&id='.(int) $this->item->id); ?>">Descargar pdf</a>
	</div>
</div>


