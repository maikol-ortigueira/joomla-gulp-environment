<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

$canEdit = JFactory::getUser()->authorise('core.edit', 'com_client.' . $this->item->id);

if (!$canEdit && JFactory::getUser()->authorise('core.edit.own', 'com_client' . $this->item->id))
{
	$canEdit = JFactory::getUser()->id == $this->item->created_by;
}
?>

<div class="item_fields">

	<table class="table">
		

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_NAME'); ?></th>
			<td><?php echo $this->item->name; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_CIF'); ?></th>
			<td><?php echo $this->item->cif; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_ALIAS'); ?></th>
			<td><?php echo $this->item->alias; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_CATID'); ?></th>
			<td><?php echo $this->item->catid; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_ADRRESS'); ?></th>
			<td><?php echo $this->item->adrress; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_CP'); ?></th>
			<td><?php echo $this->item->cp; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_CITY'); ?></th>
			<td><?php echo $this->item->city; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_ESTATE'); ?></th>
			<td><?php echo $this->item->estate; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_COUNTRY'); ?></th>
			<td><?php echo $this->item->country; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_EMAIL'); ?></th>
			<td><?php echo $this->item->email; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_TLF'); ?></th>
			<td><?php echo $this->item->tlf; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_INV_OTHER'); ?></th>
			<td></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_INV_ADRRESS'); ?></th>
			<td><?php if( $this->item->inv_other == No ) echo $this->item->inv_adrress; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_INV_CP'); ?></th>
			<td><?php echo $this->item->inv_cp; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_INV_CITY'); ?></th>
			<td><?php echo $this->item->inv_city; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_INV_ESTATE'); ?></th>
			<td><?php echo $this->item->inv_estate; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_INV_COUNTRY'); ?></th>
			<td><?php echo $this->item->inv_country; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_INV_EMAIL'); ?></th>
			<td><?php echo $this->item->inv_email; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_CONTACT_NAME'); ?></th>
			<td><?php echo $this->item->contact_name; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_CONTACT_POSITION'); ?></th>
			<td><?php echo $this->item->contact_position; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_CONTACTE_MAIL'); ?></th>
			<td><?php echo $this->item->contacte_mail; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_CONTACT_TLF'); ?></th>
			<td><?php echo $this->item->contact_tlf; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_SEND_TRANSLATIONS'); ?></th>
			<td></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_ORTRANSLATOR_FORM_LBL_CLIENT_USERS_ID'); ?></th>
			<td><?php echo $this->item->users_id; ?></td>
		</tr>

	</table>

</div>

<?php if($canEdit && $this->item->checked_out == 0): ?>

	<a class="btn" href="<?php echo JRoute::_('index.php?option=com_client&task=client.edit&id='.$this->item->id); ?>"><?php echo JText::_("COM_ORTRANSLATOR_EDIT_ITEM"); ?></a>

<?php endif; ?>

<?php if (JFactory::getUser()->authorise('core.delete','com_client.client.'.$this->item->id)) : ?>

	<a class="btn btn-danger" href="#deleteModal" role="button" data-toggle="modal">
		<?php echo JText::_("COM_ORTRANSLATOR_DELETE_ITEM"); ?>
	</a>

	<div id="deleteModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="deleteModal" aria-hidden="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			<h3><?php echo JText::_('COM_ORTRANSLATOR_DELETE_ITEM'); ?></h3>
		</div>
		<div class="modal-body">
			<p><?php echo JText::sprintf('COM_ORTRANSLATOR_DELETE_CONFIRM', $this->item->id); ?></p>
		</div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal">Close</button>
			<a href="<?php echo JRoute::_('index.php?option=com_client&task=client.remove&id=' . $this->item->id, false, 2); ?>" class="btn btn-danger">
				<?php echo JText::_('COM_ORTRANSLATOR_DELETE_ITEM'); ?>
			</a>
		</div>
	</div>

<?php endif; ?>