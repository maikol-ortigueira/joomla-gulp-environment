<?php

/**
 * @version    3.2
 * @package    com_client
 * @author     Maikol Fustes <maikol.ortigueira@gmail.com>
 * @copyright  2019 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

require_once JPATH_COMPONENT_SITE  . '/helpers/dompdf/autoload.inc.php';

use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use Dompdf\Dompdf;

$css = (Uri::root() . 'media/com_client/css/pdf.css');

$layout = new JLayoutFile('invoice-quote', NULL, array('client' => 1));

$data = ClientHelpersClient::getQuoteData($this->item, $this->params);

$data->company_logo = JPATH_ROOT . "/" .$data->company_logo;

$content = $layout->render($data);
$html ='<link type="text/css" ';
$html .='href="'. $css . '" ';
$html .='rel="stylesheet" />';

$html .= $content; //or any other field you like

$dompdf = new Dompdf();
$dompdf->set_option('isHtml5ParserEnabled', true);
$dompdf->setPaper('A4', 'portrait');
$dompdf->setBasePath(JPATH_COMPONENT_SITE . '/helpers/dompdf');
$dompdf->loadHtml($html);
$dompdf->render();
$dompdf->output();

$filename = $this->item->title . '.pdf';

$dompdf->stream($filename);
