
function getQuote(wherevalue) {
	getOptions(['id', 'quote_num'],'client.quotes','client_id',wherevalue,'=').done(function (result) {
		jQuery('#jform_quote_id').html(result);
		jQuery('#jform_quote_id').val(quoteId);
		jQuery('#jform_quote_id').trigger('liszt:updated');
	});
}

// Método que genera el número de presupuesto
function getQuoteRef(quoteRefPrefix, quoteNumLong) {
	qNum = jQuery('#jform_quote_num').val();
	quoteNumero = pad(qNum, quoteNumLong);
	console.log(qNum);
	var quoteRef = quoteRefPrefix + '-' + quoteNumero;

	jQuery('#jform_title').val(quoteRef);
}

// Método que genera el número de factura
function getInvoiceRef(invoiceRefPrefix, invoiceNumLong) {
	iNum = jQuery('#jform_invoice_num').val();
	invoiceNumero = pad(iNum, invoiceNumLong);
	console.log(iNum);
	var invoiceRef = invoiceRefPrefix + '-' + invoiceNumero;

	jQuery('#jform_title').val(invoiceRef);
}

/**
 * Método para recuperar valores de una tabla vía ajax
 * @param  {array} fields     Array con los campos a recuperar
 * @param  {string} table      nombre de la tabla sustituyendo _ por un punto
 * @param  {string} where      Campo condicional
 * @param  {string} wherevalue Valor que deberá tener el campo condicional
 * @param  {string} condition  tipo comparativo
 * @return {json}            Valores de los campos solicitados.
 */
function getOptions(fields, table, where, wherevalue,condition) {
	var getUrl    = "index.php?option=com_client&task=ajax.getOptions&format=json";

	if (token.length > 0 && wherevalue > 0) {
		var request = 'token='+token+'&wherevalue='+wherevalue+'&fields='+fields+'&table='+table+'&where='+where+'&condition='+condition;
	}

	return jQuery.ajax({
		url: getUrl,
		type: 'GET',
		dataType: 'jsonp',
		data: request,
		jsonp: 'callback'
	});
}

// Función para rellenar con ceros ó z hasta completar n número de caracteres
function pad(n, width, z) {
  z = z || '0';
  n = n + '';
  return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
}