jQuery(document).on('focusout','.integer', function () {
	this.value = parseInt(this.value);
	if (isNaN(this.value)) {
		this.value = "";
	}
});

jQuery(document).on('focusout','.float', function () {
	this.value = parseFloat(this.value);
	if (isNaN(this.value)) {
		this.value = "";
	}
});

function getIdPrefix(id) {
	var target = id.split('__');

	return ('#' + target[0] + '__' + target[1] + '__');
}
/**
 * Método para actualizar las opciones del selector de presupuestos en función del cliente
 * @param  {int} wherevalue id del cliente
 * @return {}            actualiza automáticamente el selector
 */
function getQuote(clientId) {
	getOptions(['id', 'title'],'client.quotes','client_id',clientId,'=').done(function (result) {
		jQuery('#jform_quote_id').html(result);
		jQuery('#jform_quote_id').val(quoteId);
		jQuery('#jform_quote_id').trigger('liszt:updated');
	});
}

/**
 * Método que genera un número de referencia
 * @param  {json} 	ref     	Prefijo y sufijo a partir del número de referencia.
 * @param  {int} 		numLong 	Longitud del número utilizado en la referencia. Se añadirán X ceros antes del número hasta completar esta longitud.
 * @param  {string} 	valFrom 	Identificador de campo de donde se extrae el número sin el prefijo jform_.
 * @param  {string} 	valTo   	Identificador en donde se volcará el resultado
 * @return {void}         		Automáticamente se modificará el valor del campo valTo
 */
function setRef(ref, numLong, valFrom, valTo) {
	numVal = jQuery('#jform_'+valFrom).val();
	formatedNum = pad(numVal, numLong);
	ref = JSON.parse(ref);

	var newRef = ref.preNum + formatedNum + ref.postNum;

	jQuery('#jform_'+valTo).val(newRef);
}

// ################# LLAMADAS AJAX ##########################
/**
 * Método para recuperar valores de una tabla vía ajax
 * @param  {array} fields     Array con los campos a recuperar
 * @param  {string} table      nombre de la tabla sustituyendo _ por un punto
 * @param  {string} where      Campo condicional
 * @param  {string} wherevalue Valor que deberá tener el campo condicional
 * @param  {string} condition  tipo comparativo
 * @return {json}            Valores de los campos solicitados.
 */
function getOptions(fields, table, where, wherevalue,condition) {
	var getUrl    = "index.php?option=com_client&task=ajax.getOptions&format=json";

	if (token.length > 0 && wherevalue > 0) {
		var request = 'token='+token+'&wherevalue='+wherevalue+'&fields='+fields+'&table='+table+'&where='+where+'&condition='+condition;
	}

	return jQuery.ajax({
		url: getUrl,
		type: 'GET',
		dataType: 'jsonp',
		data: request,
		jsonp: 'callback'
	});
}

function sendEmail(data0) {
	var getUrl    = "index.php?option=com_client&task=ajax.sendEmail&format=json";

	if (token.length > 0 && data0.email_to != "") {

		var request = {
			token:token,
			data0:data0
		};
	}

	return jQuery.ajax({
		url: getUrl,
		type: 'GET',
		dataType: 'jsonp',
		data: request,
		jsonp: 'callback'
	});
}

function getValue(field, table, wherevalue, where = 'id', condition = '=') {
	var getUrl = "index.php?option=com_client&task=ajax.getValue&format=json";

	if (token.length > 0 && wherevalue != "") {
		var request = 'token='+token+'&wherevalue='+wherevalue+'&field='+field+'&table='+table+'&where='+where+'&condition='+condition;
	}

	return jQuery.ajax({
		url: getUrl,
		type: 'GET',
		dataType: 'jsonp',
		data: request,
		jsonp: 'callback'
	});
}

// ################# FIN DE LLAMADAS AJAX ##########################

/**
 * Método para obtener el precio de un idioma de traducción
 * @param  {string} idioma      Identificador del idioma
 * @param  {String} presupuesto Identificador del presupuesto
 * @param  {object} priceField  Campo precio del formulario
 * @return {string}             El precio
 */
function setNewLineValues(idioma, presupuesto = "", priceField, totalWords, amountField) {
	if (presupuesto != "") {
		// Si tiene presupuesto recupero la linea de presupuesto para el idioma
		getValue('quote_translation_lines', 'client.quotes', presupuesto).done(function (result){
			var resultado = JSON.parse(result);
			jQuery.each(resultado, function(index, val) {
				var actualizado = 0;
				if (val.languages == idioma) {
					var precio = parseFloat(val.price).toFixed(3);

					priceField.val(precio);
					amountField.val((precio*totalWords).toFixed(2));

					actualizado = 1;

					return precio;
				}
				// Si dentro del presupuesto no existe precio para el idioma debo recuperar el precio del idioma de la tabla de idiomas
				if (actualizado === 0) {
					getValue('price_1', 'client.languages', idioma).done(function (result){
						var precio = parseFloat(result).toFixed(3);

						priceField.val(precio);
						amountField.val((precio*totalWords).toFixed(2));


						return precio;
					});

				}
			});
		})
	}
	else
	{
		// Si no tiene presupuesto cojemos el valor de precio de la tabla de idiomas
		getValue('price_1', 'client.languages', idioma).done(function (result){
			//priceField.val(result);
			precio = parseFloat(result).toFixed(3);

			priceField.val(precio);
			amountField.val((precio*totalWords).toFixed(2));
		});
	}

}

function precioIdioma(idioma){
	getValue('price_1', 'client.languages', idioma).done(function (resultado){
		var precio = parseFloat(resultado).toFixed(3);

		return precio;
	})
}

// Método utilizado en translation view para recuperar lista de traductores según idioma para el subform
function getLangTranslators(languageId, translatorField) {
	getOptions(['id', 'name'],'client.translators','language_id',languageId,'find_in_set').done(function (result) {
		console.log(result);
		translatorField.html(result);
		translatorField.trigger('liszt:updated');
	});

}


function sendEmailToTranslator(button) {
	var lineId = getIdPrefix(button.id);
	var translatorId = jQuery(lineId+'translator_id').val();
}

// Función para rellenar con ceros ó z hasta completar n número de caracteres
function pad(n, width, z) {
  z = z || '0';
  n = n + '';
  return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
}