/**
 * @version     CVS: 1.0.0
 * @package     com_client
 * @subpackage  mod_client
 * @copyright   2020 Maikol Fustes
 * @license     Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 * @author      Maikol Fustes <maikol@maikol.eu>
 */


