<?php
/**
 * @version     CVS: 1.0.0
 * @package     com_client
 * @subpackage  mod_client
 * @author      Maikol Fustes <maikol@maikol.eu>
 * @copyright   2020 Maikol Fustes
 * @license     Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
defined('_JEXEC') or die;
$elements = ModClientHelper::getList($params);
?>

<?php if (!empty($elements)) : ?>
	<table class="table">
		<?php foreach ($elements as $element) : ?>
			<tr>
				<th><?php echo ModClientHelper::renderTranslatableHeader($params, $params->get('field')); ?></th>
				<td><?php echo ModClientHelper::renderElement(
						$params->get('table'), $params->get('field'), $element->{$params->get('field')}
					); ?></td>
			</tr>
		<?php endforeach; ?>
	</table>
<?php endif;
