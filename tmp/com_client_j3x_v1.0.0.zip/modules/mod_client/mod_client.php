<?php

/**
 * @version     CVS: 1.0.0
 * @package     com_client
 * @subpackage  mod_client
 * @author      Maikol Fustes <maikol@maikol.eu>
 * @copyright   2020 Maikol Fustes
 * @license     Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Helper\ModuleHelper;

// Include the syndicate functions only once
JLoader::register('ModClientHelper', dirname(__FILE__) . '/helper.php');

$doc = Factory::getDocument();

/* */
$doc->addStyleSheet(URI::base() . 'media/mod_client/css/style.css');

/* */
$doc->addScript(URI::base() . 'media/mod_client/js/script.js');

require ModuleHelper::getLayoutPath('mod_client', $params->get('content_type', 'blank'));
