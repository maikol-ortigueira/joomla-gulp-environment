<?php

/**
 * @version     CVS: 1.0.0
 * @package     com_client
 * @subpackage  mod_client
 * @author      Maikol Fustes <maikol@maikol.eu>
 * @copyright   2020 Maikol Fustes
 * @license     Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;

/**
 * Helper for mod_client
 *
 * @package     com_client
 * @subpackage  mod_client
 * @since       1.6
 */
class ModClientHelper
{
	/**
	 * Retrieve component items
	 *
	 * @param   Joomla\Registry\Registry &$params module parameters
	 *
	 * @return array Array with all the elements
     *
     * @throws Exception
	 */
	public static function getList(&$params)
	{
		$app   = Factory::getApplication();
		$db    = Factory::getDbo();
		$query = $db->getQuery(true);

		/* @var $params Joomla\Registry\Registry */
		$query
			->select('*')
			->from($params->get('table'))
			->where('state = 1');

		$db->setQuery($query, $app->input->getInt('offset', (int) $params->get('offset')), $app->input->getInt('limit', (int) $params->get('limit')));
		$rows = $db->loadObjectList();

		return $rows;
	}

	/**
	 * Retrieve component items
	 *
	 * @param   Joomla\Registry\Registry &$params module parameters
	 *
	 * @return mixed stdClass object if the item was found, null otherwise
	 */
	public static function getItem(&$params)
	{
		$db    = Factory::getDbo();
		$query = $db->getQuery(true);

		/* @var $params Joomla\Registry\Registry */
		$query
			->select('*')
			->from($params->get('item_table'))
			->where('id = ' . intval($params->get('item_id')));

		$db->setQuery($query);
		$element = $db->loadObject();

		return $element;
	}

	/**
	 * Render element
	 *
	 * @param   Joomla\Registry\Registry $table_name  Table name
	 * @param   string                   $field_name  Field name
	 * @param   string                   $field_value Field value
	 *
	 * @return string
	 */
	public static function renderElement($table_name, $field_name, $field_value)
	{
		$result = '';
		
		switch ($table_name)
		{
			
		case '#__clients':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'name':
		$result = $field_value;
		break;
		case 'cif':
		$result = $field_value;
		break;
		case 'alias':
		$result = $field_value;
		break;
		case 'catid':
		$result = self::loadValueFromExternalTable('#__categories', 'id', 'title', $field_value);
		break;
		case 'adrress':
		$result = $field_value;
		break;
		case 'cp':
		$result = $field_value;
		break;
		case 'city':
		$result = $field_value;
		break;
		case 'estate':
		$result = $field_value;
		break;
		case 'country':
		$result = $field_value;
		break;
		case 'email':
		$result = $field_value;
		break;
		case 'tlf':
		$result = $field_value;
		break;
		case 'inv_other':
		$result = $field_value;
		break;
		case 'inv_adrress':
		$result = $field_value;
		break;
		case 'inv_cp':
		$result = $field_value;
		break;
		case 'inv_city':
		$result = $field_value;
		break;
		case 'inv_estate':
		$result = $field_value;
		break;
		case 'inv_country':
		$result = $field_value;
		break;
		case 'inv_email':
		$result = $field_value;
		break;
		case 'contact_name':
		$result = $field_value;
		break;
		case 'contact_position':
		$result = $field_value;
		break;
		case 'contacte_mail':
		$result = $field_value;
		break;
		case 'contact_tlf':
		$result = $field_value;
		break;
		case 'send_translations':
		$result = $field_value;
		break;
		case 'users_id':
		$result = self::loadValueFromExternalTable('#__users', 'id', 'name,email', $field_value);
		break;
		}
		break;
		case '#__client_translations':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'uploaded_file':
						if (!empty($field_value)) {
							$result = JPATH_ADMINISTRATOR . 'components/com_client/translations/' . $field_value;
						} else {
							$result = $field_value;
						}
		break;
		case 'client_id':
		$result = self::loadValueFromExternalTable('#__clients', 'id', 'name', $field_value);
		break;
		case 'words':
		$result = $field_value;
		break;
		case 'quote_id':
		$result = $field_value;
		break;
		case 'origin_filename':
		$result = $field_value;
		break;
		case 'filename':
		$result = $field_value;
		break;
		case 'uploaded_date':
		$result = $field_value;
		break;
		case 'lines':
		$result = $field_value;
		break;
		}
		break;
		case '#__client_translators':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'name':
		$result = $field_value;
		break;
		case 'alias':
		$result = $field_value;
		break;
		case 'cif':
		$result = $field_value;
		break;
		case 'adrress':
		$result = $field_value;
		break;
		case 'cp':
		$result = $field_value;
		break;
		case 'city':
		$result = $field_value;
		break;
		case 'estate':
		$result = $field_value;
		break;
		case 'email':
		$result = $field_value;
		break;
		case 'tlf':
		$result = $field_value;
		break;
		case 'contact_name':
		$result = $field_value;
		break;
		case 'contact_position':
		$result = $field_value;
		break;
		case 'contacte_mail':
		$result = $field_value;
		break;
		case 'contact_tlf':
		$result = $field_value;
		break;
		case 'send_translations_to':
		$result = $field_value;
		break;
		case 'language_id':
		$result = self::loadValueFromExternalTable('#__client_languages', 'id', '', $field_value);
		break;
		}
		break;
		case '#__client_invoices':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'client_id':
		$result = self::loadValueFromExternalTable('#__clients', 'id', 'name', $field_value);
		break;
		case 'invoice_date':
		$result = $field_value;
		break;
		case 'invoice_num':
		$result = $field_value;
		break;
		case 'quote_id':
		$result = $field_value;
		break;
		case 'title':
		$result = $field_value;
		break;
		case 'pdf_done':
		$result = $field_value;
		break;
		case 'pdf_file':
		$result = $field_value;
		break;
		case 'client_data':
		$result = $field_value;
		break;
		case 'iva':
		$result = $field_value;
		break;
		case 'invoice_lines':
		$result = $field_value;
		break;
		case 'terms':
		$result = $field_value;
		break;
		}
		break;
		case '#__client_quotes':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'client_id':
		$result = self::loadValueFromExternalTable('#__clients', 'id', 'name', $field_value);
		break;
		case 'quote_date':
		$result = $field_value;
		break;
		case 'quote_num':
		$result = $field_value;
		break;
		case 'title':
		$result = $field_value;
		break;
		case 'pdf_done':
		$result = $field_value;
		break;
		case 'pdf_file':
		$result = $field_value;
		break;
		case 'client_data':
		$result = $field_value;
		break;
		case 'quote_lines':
		$result = $field_value;
		break;
		case 'terms':
		$result = $field_value;
		break;
		}
		break;
		case '#__client_languages':
		switch($field_name){
		case 'id':
		$result = $field_value;
		break;
		case 'created_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'modified_by':
		$user = JFactory::getUser($field_value);
		$result = $user->name;
		break;
		case 'language_from':
		$result = $field_value;
		break;
		case 'country_from':
		$result = $field_value;
		break;
		case 'tag_from':
		$result = $field_value;
		break;
		case 'language_to':
		$result = $field_value;
		break;
		case 'country_to':
		$result = $field_value;
		break;
		case 'tag_to':
		$result = $field_value;
		break;
		}
		break;
		}

		return $result;
	}

	/**
	 * Returns the translatable name of the element
	 *
	 * @param   Joomla\Registry\Registry &$params Module parameters
	 * @param   string                   $field   Field name
	 *
	 * @return string Translatable name.
	 */
	public static function renderTranslatableHeader(&$params, $field)
	{
		return Text::_(
			'MOD_CLIENT_HEADER_FIELD_' . str_replace('#__', '', strtoupper($params->get('table'))) . '_' . strtoupper($field)
		);
	}

	/**
	 * Checks if an element should appear in the table/item view
	 *
	 * @param   string $field name of the field
	 *
	 * @return boolean True if it should appear, false otherwise
	 */
	public static function shouldAppear($field)
	{
		$noHeaderFields = array('checked_out_time', 'checked_out', 'ordering', 'state');

		return !in_array($field, $noHeaderFields);
	}

	

    /**
     * Method to get a value from a external table
     * @param string $source_table Source table name
     * @param string $key_field Source key field 
     * @param string $value_field Source value field
     * @param mixed  $key_value Value for the key field
     * @return mixed The value in the external table or null if it wasn't found
     */
    private static function loadValueFromExternalTable($source_table, $key_field, $value_field, $key_value) {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $query
                ->select($db->quoteName($value_field))
                ->from($source_table)
                ->where($db->quoteName($key_field) . ' = ' . $db->quote($key_value));


        $db->setQuery($query);
        return $db->loadResult();
    }
}
