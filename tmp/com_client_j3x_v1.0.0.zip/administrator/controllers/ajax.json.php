<?php
/**
 * @version    3.2
 * @package    com_client
 * @author     Maikol Fustes <maikol.ortigueira@gmail.com>
 * @copyright  2019 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

// Import Joomla controllerform library
jimport('joomla.application.component.controller');

use \Joomla\CMS\Factory;
use \Joomla\CMS\Session\session;
//use \Joomla\CMS\Application\WebApplication;

/**
 * Client Ajax Controller
 */
class ClientControllerAjax extends \Joomla\CMS\MVC\Controller\BaseController
{
	public function __construct($config)
	{
		parent::__construct($config);
		// make sure all json staff are set
		Factory::getDocument()->setMimeEncoding('application/json');
		JResponse::setHeader('Content-Disposition','attachment;filename="getajax.json"');
		JResponse::setHeader("Access-Control-Allow-Origin", "*");

		//Load the tasks
		$this->registerTask('getOptions', 'ajax');
		$this->registerTask('getValue', 'ajax');
		$this->registerTask('sendEmail', 'ajax');
	}

	public function ajax()
	{
		$user		=	Factory::getUser();
		$jinput	=	Factory::getApplication()->input;

		// Check Token!
		$token 	=	session::getFormToken();
		$call_token =	$jinput->get('token', 0, 'ALNUM');

		if ($token == $call_token) {
			$task = $this->getTask();

			switch ($task) {
				case 'getOptions':
					try
					{
						$fields 	=	explode(",", $jinput->get('fields', 0, 'STRING'));
						$table	=	str_replace('.', '_', $jinput->get('table', 'client', 'CMD'));
						$where 	=	$jinput->get('where', 'id', 'STRING');
						$wherevalue =	$jinput->get('wherevalue', 0, 'STRING');
						$condition =	$jinput->get('condition', "=", 'STRING');

						if ($wherevalue && $user->id != 0)
						{
							$result = $this->getModel('ajax')->getOptions($fields, $table, $where, $condition, $wherevalue);
						}
						else
						{
							$result = false;
						}
						if ($callback = $jinput->get('callback', null, 'CMD'))
						{
							echo $callback . "(" . json_encode($result) . ");";
						}
						elseif ($returnRaw)
						{
							echo json_encode($result);
						}
						else
						{
							echo "(" . json_encode($result) . ");";
						}
					}
					catch(Exception $e)
					{
						if ($callback = $jinput->get('callback', null, 'CMD'))
						{
							echo $callback . "(" . json_encode($e) . ");";
						}
						else
						{
							echo "(" . json_encode($e) . ");";
						}
					}
				break;
				case 'getValue':
					try
					{
						$field 	=	$jinput->get('field', 0, 'STRING');
						$table	=	str_replace('.', '_', $jinput->get('table', 'client', 'CMD'));
						$where 	=	$jinput->get('where', 'id', 'STRING');
						$wherevalue =	$jinput->get('wherevalue', 0, 'STRING');
						$condition =	$jinput->get('condition', '=', 'STRING');

						if ($field && $user->id != 0)
						{
							$result = $this->getModel('ajax')->getValue($field, $table, $where, $condition, $wherevalue);
						}
						else
						{
							$result = false;
						}
						if ($callback = $jinput->get('callback', null, 'CMD'))
						{
							echo $callback . "(" . json_encode($result) . ");";
						}
						elseif ($returnRaw)
						{
							echo json_encode($result);
						}
						else
						{
							echo "(" . json_encode($result) . ");";
						}
					}
					catch(Exception $e)
					{
						if ($callback = $jinput->get('callback', null, 'CMD'))
						{
							echo $callback . "(" . json_encode($e) . ");";
						}
						else
						{
							echo "(" . json_encode($e) . ");";
						}
					}
				break;
				case 'sendEmail':
					try
					{
						$data 	=	$jinput->get('data0', '', 'ARRAY');

						if ($data['email_to'] && $user->id != 0)
						{
							$result = $this->getModel('ajax')->sendEmail($data);
						}
						else
						{
							$result = false;
						}
						if ($callback = $jinput->get('callback', null, 'CMD'))
						{
							echo $callback . "(" . json_encode($result) . ");";
						}
						elseif ($returnRaw)
						{
							echo json_encode($result);
						}
						else
						{
							echo "(" . json_encode($result) . ");";
						}
					}
					catch(Exception $e)
					{
						if ($callback = $jinput->get('callback', null, 'CMD'))
						{
							echo $callback . "(" . json_encode($e) . ");";
						}
						else
						{
							echo "(" . json_encode($e) . ");";
						}
					}
				break;


			}
		}
		else
		{
			if($callback = $jinput->get('callback', null, 'CMD'))
			{
				echo $callback . "(" . json_encode(false) . ");";
			}
			else
			{
				echo "(" . json_encode(false) . ");";
			}
		}
	}
}