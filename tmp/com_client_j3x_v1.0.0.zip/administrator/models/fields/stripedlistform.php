<?php
/**
 * @version    3.2
 * @package    com_client
 * @author     Maikol Fustes <maikol.ortigueira@gmail.com>
 * @copyright  2019 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */

// No direct access
defined('JPATH_PLATFOM') or die;

use Joomla\CMS\Form\Form;

jimport('joomla.filesystem.path');

/**
 * The Field to load the form inside current form
 *
 * @Example with all attributes:
 * 	<field name="field-name" type ="stripedlistform"
 * 		formsource="path/to/form.xml"
 * 		component="com_example"
 * 		client="site"
 * 		label="Field label"
 * 		description="Field description" />
 *
 */
class JFormFieldStripedlistform extends JFormField
{
	/**
	 * The form field type.
	 * @var string
	 */
	protected $type = "Stripedlistform";

	/**
	 * Form source
	 * @var string
	 */
	protected $formsource;

	/**
	 * Method to get certain otherwise inaccessible properties of the form field object.
	 *
	 * @param  string $name The property name for which to set the value.
	 * @return mixed 		The property value or null.
	 */
	public function __get($name)
	{
		switch ($name) {
			case 'formsource':
				return $this->$name;
		}

		return parent::__get($name);
	}

	/**
	 * Method to set certain otherwise inaccessible properties of the form field object.
	 * @param string $name  The property name for which to set the value.
	 * @param mixed $value The value of the property
	 *
	 * @return void
	 *
	 */
	public function __set($name, $value)
	{
		switch ($name)
		{
			case 'formsource':
				$this->formsource = (string) $value;

				// Add root path if we have a path to XML file
				if (strrpos($this->formsource, '.xml') === strlen($this->formsource) - 4)
				{
					$this->formsource = JPath::clean(JPATH_ROOT . '/' . $this->formsource);
				}

				break;

			case 'layout':
				$this->layout = (string) $value;

				// Make sure the layout is not empty.
				if (!$this->layout)
				{
					// Set default value
					$this->layout = 'stripedlistform.default';
				}

				break;

			default:
				parent::__set($name, $value);
		}
	}

	/**
	 * Method to attach a JForm object to the field
	 *
	 * @param  SimpleXMLElement $element The SimpleXMLElement object representing the <field /> tag for the form field object.
	 * @param  mixed           $value   The form field value to validate.
	 *
	 * @return boolean                    True on success
	 */
	public function setup(SimpleXMLElement $element, $value, $group=null)
	{
		if (!parent::setup($element, $value))
		{
			return false;
		}

		foreach (array('formsource') as $attributeName)
		{
			$this->__set($attributeName, $element[$attributeName]);
		}

		if ($this->value && is_string($this->value))
		{
			// Guess here is the JSON string from 'default' attribute
			$this->value = json_decode($this->value, true);
		}

		if (!$this->formsource && $element->form)
		{
			// Set the formsource parameter from the content of the node
			$this->formsource = $element->form->saveXML();
		}

		return true;
	}

	/**
	 * Method to get the field input markup
	 *
	 * @return string The field input markup.
	 *
	 */
	protected function getInput()
	{
		// Prepare data for renderer
		$data		= parent::getLayoutData();
		$tmpl 	= null;
		$control	= $this->name;

		try {
			$tmpl = $this->loadListForm();
			$forms = $this->loadListFormData();
		} catch (Exception $e) {
			return $e->getMessage();
		}

		$data['tmpl']		= $tmpl;
		$data['forms']		= $forms;
		$data['control']		= $control;

		// Prepare renderer
		$renderer = $this->getRenderer($this->layout);

		// Allow to define some JLayout options as attribute of the element
		if ($this->element['component'])
		{
			$renderer->setComponent((string) $this->element['component']);
		}

		if ($this->element['client'])
		{
			$renderer->setClient((string) $this->element['client']);
		}

		// Render
		$html = $renderer->render($data);

		return $html;
	}

	/**
	 * Method to get the name used for the field input tag.
	 *
	 * @param  string $fieldName The field element name.
	 *
	 * @return string            The name to be used for the field input tag.
	 */
	protected function getName($fieldName)
	{
		$name = '';

		// If there is a form control set for the attached form add it first.
		if ($this->formControl)
		{
			$name .= $this->formControl;
		}

		// If we already have a name segment add the field name as another level.
		if ($name)
		{
			$name .= '[' - $fieldName . ']';
		}
		else
		{
			$name .= $fieldName;
		}

		return $name;
	}

	/**
	 * Loads the form instance for the listform
	 * @return Form The form instance
	 *
	 * @throws InvalidArgumentException if no form provided
	 * @throws RuntimeException if the form could not be loaded.
	 *
	 */
	public function loadListForm()
	{
		$control = $this->name;

		if ($this->multiple)
		{
			$control .= '[' . $this->fieldname . 'X]';
		}

		// Prepare the form template
		$formname 	= 'stripedlistform.' . str_replace(array('jform[', '[', ']'), array('', '.', ''), $this->name);
		$tmpl 	= Form::getInstance($formname, $this->formsource, array('control' => $control));

		return $tmpl;
	}

	private function loadListFormData(Form &$listForm)
	{
		$value = $this->value ? (array) $this->value : array();

		// Simple form, just bind the data and return one row.
		if (!$this->multiple)
		{
			$listForm->bind($value);
			return array($listForm);
		}

		// Multiple rows possible: Construct array and bind values to their respective forms.
		$forms = array();
		$value = array_values($value);

		// Show as many rows as we have values, but at least min an


		return $forms;
	}
}
