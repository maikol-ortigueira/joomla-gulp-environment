<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */

defined('JPATH_BASE') or die;

jimport('joomla.html.html');
jimport('joomla.form.formfield');

use \Joomla\CMS\Language\Text;

/**
 * Class to generate a button for use in forms
 *
 * Optional fields are:
 * button_text 		Text that will be shown in the button.
 * button_icon 		Button icon. see https://getbootstrap.com/2.3.2/base-css.html#icons Just add the name from "icon-".
 * button_tooltip 	Message that will be shown when passing the mouse over the button.
 * button_class 		Button type class. The options are primary, info, success, warning, danger, inverse, link. See https://getbootstrap.com/2.3.2/base-css.html#buttons.
 * button_size 		Size of the button. The options are large, small, mini.
 * button_href 		URL where the button sends us. Default #.
 * translate 		If you want to translate the tooltip and button_text strings this attribute must have the value "true".
 * onclick 			Javascript action that is executed when the button is pressed.
 *
 * @since  1.6
 */
class JFormFieldCustombutton extends \Joomla\CMS\Form\FormField
{
	/**
	 * The form field type.
	 *
	 * @var        string
	 * @since    1.6
	 */
	protected $type = 'custombutton';

	protected $button_text;
	protected $button_icon;
	protected $button_tooltip;
	protected $button_class;
	protected $button_size;
	protected $button_href;
	protected $onclick;
	protected $translate;
	protected $class;

	/**
	 * Method to get the field input markup.
	 *
	 * @return    string    The field input markup.
	 *
	 * @since    1.6
	 */
	protected function getInput()
	{

		// Text to add to the button
		$this->button_text = $this->getAttribute('button_text');

		// button icon
		$this->button_icon = $this->getAttribute('button_icon');

		// Button tooltip
		$this->button_tooltip = $this->getAttribute('button_tooltip');

		// button type class
		$this->button_class = $this->getAttribute('button_class');

		// Button size
		$this->button_size = $this->getAttribute('button_size');

		// Button link URL
		$this->button_href = $this->getAttribute('button_href');

		// Function onclick
		$this->onclick = $this->getAttribute('onclick');

		// Translate the string
		$this->translate = $this->getAttribute('translate');

		// Button class
		$this->class = $this->getAttribute('class');


		// Source generation
		$class = 'btn';

		// If we have a button type
		if ($this->button_class != "") {
			$class .= ' btn-' . $this->button_class;
		}

		// Do we have a class?
		if ($this->class != "") {
			$class .= ' ' . $this->class;
		}

		// Do we have a button size?
		if ($this->button_size != "") {
			$class .= ' btn-' . $this->button_size;
		}

		// HTML beginning
		$html = '<a';

		// Button Id
		$html .= ' id="' . $this->id . '"';


		// Do we have a tooltip?
		if ($this->button_tooltip != "")
		{
			// Add hasTooltip class
			$class .= ' hasTooltip';

			if ($this->translate)
			{
				$this->button_tooltip = Text::_($this->button_tooltip);
			}

			$html .= ' data-toggle="tooltip"';
			$html .= ' title="' . $this->button_tooltip . '"';
		}

		// Class data
		$html .= ' class="' . $class . '"';

		// URL data
		$href = '#';

		// Do we have a href link?
		if ($this->button_href != "")
		{
			$href = $this->button_href;
		}

		$html .= ' href="' . $href . '"';

		// Do we have onclick funtion?
		if ($this->onclick != "")
		{
			$html .= ' onclick="return ' . $this->onclick . '"';
		}

		// Close <a> tag
		$html .= '>';


		// Button icon
		if ($this->button_icon != "")
		{
			$html .= '<i class="icon-' . $this->button_icon . '"></i>';
		}

		// Button text
		if ($this->button_text != "")
		{
			if ($this->translate == true)
			{
				$this->button_text = Text::_($this->button_text);
			}
			$html .= ' ' . $this->button_text;
		}

		// </a> closing tag
		$html .= '</a>';
		// Place to append a text
		$html .= '<div id="' . $this->id . '-text" class="div-done" style="display:none">';
		$html .= Text::_($this->element['message']);
		$html .= '</div>';

		return $html;
	}

	protected function getLabel()
	{
		return false;
	}
}
