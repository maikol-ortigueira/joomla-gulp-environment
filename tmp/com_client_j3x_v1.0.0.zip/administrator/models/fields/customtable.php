<?php
/**
 * @package     Joomla.Platform
 * @subpackage  Form
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE
 */

defined('JPATH_PLATFORM') or die;

use Joomla\CMS\Form\Form;
use \Joomla\CMS\Factory;

jimport('joomla.filesystem.path');

/**
 * The Field to load the form inside current form
 *
 * @Example with all attributes:
 * 	<field name="field-name" type="customtable"
 * 		formsource="path/to/form.xml" table="idiomas_paises" tab="tag_from" rows="tag_to"
 * 		layout="striped-table" groupByFieldset="false" component="com_example" client="site"
 * 		description="Field Description" />
 *
 * @since  3.6
 */
class JFormFieldCustomTable extends JFormField
{

	/**
	 * The form field type.
	 * @var    string
	 */
	protected $type = 'Customtable';

	/**
	 * Form source
	 * @var string
	 */
	protected $formsource;

	/**
	 * Tabla de donde estraemos las filas de la tabla
	 * @var string
	 */
	protected $table;

	/**
	 * Campo a partir del cual creamos una pestaña
	 * @var string
	 */
	protected $tab;

	/**
	 * Campo que decide las filas de la tabla en cada pestaña
	 * @var string
	 */
	protected $rows;

	/**
	 * Plantilla que genera la tabla
	 * @var  string
	 */
	protected $layout = 'striped-table';

	/**
	 * Whether group subform fields by it`s fieldset
	 * @var boolean
	 */
	protected $groupByFieldset = false;

	/**
	 * Method to get certain otherwise inaccessible properties from the form field object.
	 *
	 * @param   string  $name  The property name for which to get the value.
	 *
	 * @return  mixed  The property value or null.
	 *
	 * @since   3.6
	 */
	public function __get($name)
	{
		switch ($name)
		{
			case 'formsource':
			case 'table':
			case 'tab':
			case 'rows':
			case 'layout':
			case 'groupByFieldset':
				return $this->$name;
		}

		return parent::__get($name);
	}

	/**
	 * Method to set certain otherwise inaccessible properties of the form field object.
	 *
	 * @param   string  $name   The property name for which to set the value.
	 * @param   mixed   $value  The value of the property.
	 *
	 * @return  void
	 *
	 * @since   3.6
	 */
	public function __set($name, $value)
	{
		switch ($name)
		{
			case 'formsource':
				$this->formsource = (string) $value;

				// Add root path if we have a path to XML file
				if (strrpos($this->formsource, '.xml') === strlen($this->formsource) - 4)
				{
					$this->formsource = JPath::clean(JPATH_ROOT . '/' . $this->formsource);
				}

				break;

			case 'groupByFieldset':
				if ($value !== null)
				{
					$value = (string) $value;
					$this->groupByFieldset = !($value === 'false' || $value === 'off' || $value === '0');
				}
				break;

			case 'table':
				$this->table = (string) $value;

				$this->table = '#__' . $this->table;

				break;

			case 'tab':
				$this->tab = (string) $value;

				break;

			case 'rows':
				$this->rows = (string) $value;

				break;

			case 'layout':
				$this->layout = (string) $value;

				break;

			default:
				parent::__set($name, $value);
		}
	}

	/**
	 * Method to attach a JForm object to the field.
	 *
	 * @param   SimpleXMLElement  $element  The SimpleXMLElement object representing the <field /> tag for the form field object.
	 * @param   mixed             $value    The form field value to validate.
	 * @param   string            $group    The field name group control value.
	 *
	 * @return  boolean  True on success.
	 *
	 * @since   3.6
	 */
	public function setup(SimpleXMLElement $element, $value, $group = null)
	{
		if (!parent::setup($element, $value, $group))
		{
			return false;
		}

		foreach (array('formsource', 'table', 'tab', 'rows', 'layout', 'groupByFieldset') as $attributeName)
		{
			$this->__set($attributeName, $element[$attributeName]);
		}

		if ($this->value && is_string($this->value))
		{
			// Guess here is the JSON string from 'default' attribute
			$this->value = json_decode($this->value, true);
		}

		if (!$this->formsource && $element->form)
		{
			// Set the formsource parameter from the content of the node
			$this->formsource = $element->form->saveXML();
		}

		return true;
	}

	// Para que no imprima en pantalla la etiqueta del field Principal
	protected function getLabel()
	{

	}

	/**
	 * Method to get the field input markup.
	 *
	 * @return  string  The field input markup.
	 *
	 * @since   3.6
	 */
	protected function getInput()
	{
		// Prepare data for renderer
		$data    = parent::getLayoutData();
		$tmpl    = null;
		$control = $this->name;
		$tabs = $this->getTabs();

		try
		{

			$tmpl  = $this->loadSubForm();
			$forms = $this->loadSubFormData($tmpl);
		}

		catch (Exception $e)
		{
			return $e->getMessage();
		}

		$data['tmpl']      = $tmpl;
		$data['forms']     = $forms;
		$data['control']   = $control;
		$data['fieldname'] = $this->fieldname;
		$data['groupByFieldset'] = $this->groupByFieldset;

		/**
		 * For each rendering process of a subform element, we want to have a
		 * separate unique subform id present to could distinguish the eventhandlers
		 * regarding adding/moving/removing rows from nested subforms from their parents.
		 */
		static $unique_subform_id = 0;
		$data['unique_subform_id'] = ('sr-' . ($unique_subform_id++));

		// Prepare renderer
		$renderer = $this->getRenderer($this->layout);

		// Allow to define some JLayout options as attribute of the element
		if ($this->element['component'])
		{
			$renderer->setComponent((string) $this->element['component']);
		}

		if ($this->element['client'])
		{
			$renderer->setClient((string) $this->element['client']);
		}

		// Render
		$html = $renderer->render($data);

		// Add hidden input on front of the subform inputs, in multiple mode
		// for allow to submit an empty value
		// if ($this->multiple)
		// {
		// 	$html = '<input name="' . $this->name . '" type="hidden" value="" />' . $html;
		// }

		return $html;
	}

	/**
	 * Method to get the name used for the field input tag.
	 *
	 * @param   string  $fieldName  The field element name.
	 *
	 * @return  string  The name to be used for the field input tag.
	 *
	 * @since   3.6
	 */
	protected function getName($fieldName)
	{
		$name = '';

		// If there is a form control set for the attached form add it first.
		if ($this->formControl)
		{
			$name .= $this->formControl;
		}

		// If the field is in a group add the group control to the field name.
		if ($this->group)
		{
			// If we already have a name segment add the group control as another level.
			$groups = explode('.', $this->group);

			if ($name)
			{
				foreach ($groups as $group)
				{
					$name .= '[' . $group . ']';
				}
			}
			else
			{
				$name .= array_shift($groups);

				foreach ($groups as $group)
				{
					$name .= '[' . $group . ']';
				}
			}
		}

		// If we already have a name segment add the field name as another level.
		if ($name)
		{
			$name .= '[' . $fieldName . ']';
		}
		else
		{
			$name .= $fieldName;
		}

		return $name;
	}

	/**
	 * Loads the form instance for the subform.
	 *
	 * @return  Form  The form instance.
	 *
	 * @throws  InvalidArgumentException if no form provided.
	 * @throws  RuntimeException if the form could not be loaded.
	 *
	 * @since   3.9.7
	 */
	public function loadSubForm()
	{
		$control = $this->name;

		// Prepare the form template
		$formname = 'customtable.' . str_replace(array('jform[', '[', ']'), array('', '.', ''), $this->name);
		$tmpl     = Form::getInstance($formname, $this->formsource, array('control' => $control));

		return $tmpl;
	}

	/**
	 * Binds given data to the subform and its elements.
	 *
	 * @param   Form  &$subForm  Form instance of the subform.
	 *
	 * @return  Form[]  Array of Form instances for the rows.
	 *
	 * @since   3.9.7
	 */
	private function loadSubFormData(Form &$subForm)
	{
		$value = $this->value ? (array) $this->value : array();

		// De momento solo recupero los idiomas de destino para Español de España
		// Mirar la posibilidad de hacer un foreach para todos los idiomas de procedencia
		$rows = $this->getRows('es-ES');

		$forms = array();

		// Preparo los datos para crear una fila por cada idioma destino asociado de momento al idioma de procedencia Español-España
		foreach ($rows as $row) {
			$control = $this->name . '[' . 'es-ES' . ']' . '[' . $row->{$this->rows} . ']';
			$itemForm = Form::getInstance($subForm->getName() . '['.'es-ES'.']'.'[' . $row->{$this->rows} . ']', $this->formsource, array('control' => $control));

			// Si tiene datos guardados en la bbdd los recupera
			if (!empty($value['es-ES'][$row->{$this->rows}]))
				{
					$itemForm->bind($value['es-ES'][$row->{$this->rows}]);
				}
			$forms[] = $itemForm;
		}

		return $forms;
	}

	/**
	 * Método para obtener los datos que irán en cada fila de la tabla
	 * @param  string $tab Pestaña en la que se imprimirán la tabla
	 * @return Objeto      Las filas que se imprimirán
	 */
	private function getRows($tab)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$query
			->select($this->rows)
			->from($db->quoteName($this->table))
			->where($db->quoteName($this->tab) . ' = ' . $db->quote($tab));

		$db->setQuery($query);

		return $db->loadObjectList();
	}

	/**
	 * Método que nos devuelve las distintas pestañas que se mostrarán
	 * @return objeto Valores de las pestañas
	 */
	private function getTabs()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$query
			->select('DISTINCT '. $db->quoteName($this->tab))
			->from($db->quoteName($this->table))
			->where('`state` = 1');

		$db->setQuery($query);

		return $db->loadObjectList();
	}
}
