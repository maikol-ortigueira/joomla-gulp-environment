<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */

defined('JPATH_BASE') or die;

jimport('joomla.form.formfield');
use \Joomla\CMS\Language\Text;

/**
 * Supports an HTML select list of categories
 *
 * @since  1.6
 */
class JFormFieldFileSingle extends \Joomla\CMS\Form\FormField
{
	/**
	 * The form field type.
	 *
	 * @var        string
	 * @since    1.6
	 */
	protected $type = 'file';
	protected $display;


	/**
	 * Method to get the field input markup.
	 *
	 * @return    string    The field input markup.
	 *
	 * @since    1.6
	 */
	protected function getInput()
	{
		$this->display = $this->getAttribute('display');

		$display = "";

		if (!empty($this->display))
		{
			$display = ' style="display:' . $this->display . '"';
		}

		// Initialize variables.
		$html = '<input id="' . $this->id . '" type="file" name="' . $this->name . '"'. $display .'>';

		return $html;
	}

	protected function getLabel()
	{
		$this->display = $this->getAttribute('display');

		$display = "";
		if (!empty($this->display))
		{
			$display = ' style="display:' . $this->display . '"';
		}

		// Initialize variables.
		$html = '<label id="' . $this->id . '-lbl" class="hasPopover" title="" data-content="' . Text::_($this->element['description']) . '" data-original-title="' . Text::_($this->element['label']) . '"'. $display .'>' . Text::_($this->element['label']) . '</label>';

		return $html;
	}

}
