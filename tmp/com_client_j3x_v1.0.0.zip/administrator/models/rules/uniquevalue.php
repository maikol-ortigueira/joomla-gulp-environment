<?php
/**
 * @package    Joomla.component.client
 *
 * @created    3th February 2020
 * @author     Maikol Fustes <https://www.maikol.eu>
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('JPATH_PLATFORM') or die;

use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormRule;
use Joomla\Registry\Registry;

/**
 * Form Rule (UniqueValue) class for the Joomla Platform.
 */
class JFormRuleUniqueValue extends FormRule
{
	/**
	 * Método para comprobar que un registro es único en la tabla.
	 * Podemos utilizar cualquier campo del archivo xml
	 * El valor validate debe ser = "uniquevalue"
	 * Es obligatorio indicar el nombre de la tabla en donde se coprueba el valor único separado por un punto sin prefijo.
	 * Ejemplo: validate_table="client.languages"
	 * Es obligatorio indicar los campos que se deben comprobar separados por comas.
	 * Ejemplo: validate_fields="country_from,languages_from,country_to,languages_to"
	 *
	 * @param   \SimpleXMLElement  $element  The SimpleXMLElement object representing the `<field>` tag for the form field object.
	 * @param   mixed              $value    The form field value to validate.
	 * @param   string             $group    The field name group control value. This acts as an array container for the field.
	 *                                       For example if the field has name="foo" and the group value is set to "bar" then the
	 *                                       full field name would end up being "bar[foo]".
	 * @param   Registry           $input    An optional Registry object with the entire data set to validate against the entire form.
	 * @param   Form               $form     The form object for which the field is being tested.
	 *
	 * @return  boolean  True if the value is valid, false otherwise.
	 *
	 * @since   11.1
	 */
	public function test(\SimpleXMLElement $element, $value, $group = null, Registry $input = null, Form $form = null)
	{
		$table = '#__' . str_replace(".", "_", (string)$element['validate_table']);

		if (!empty ($element['validate_fields'])) {
			$fields = explode(",", (string)$element['validate_fields']);
		}


		$db = \JFactory::getDbo();
		$query = $db->getQuery(true);

		// Build the query.
		$query->select('COUNT(*)')
			->from($db->quoteName($table));
		foreach ($fields as $field) {
			$query->where($db->quoteName($field) . " = " . $db->quote($input->get($field)));
		}

		// Set and query the database.
		$db->setQuery($query);
		$duplicate = (bool) $db->loadResult();

		if ($duplicate)
		{
			return false;
		}

		return true;
	}
}
