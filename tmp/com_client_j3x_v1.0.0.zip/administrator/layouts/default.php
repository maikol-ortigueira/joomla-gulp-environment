<?php
/**
 * @package     Joomla.Site
 * @subpackage  Layout
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/**
 * Make thing clear
 *
 * @var JForm   $tmpl             The Empty form for template
 * @var array   $forms            Array of JForm instances for render the rows
 * @var bool    $multiple         The multiple state for the form field
 * @var int     $min              Count of minimum repeating in multiple mode
 * @var int     $max              Count of maximum repeating in multiple mode
 * @var string  $fieldname        The field name
 * @var string  $control          The forms control
 * @var string  $label            The field label
 * @var string  $description      The field description
 * @var array   $buttons          Array of the buttons that will be rendered
 * @var bool    $groupByFieldset  Whether group the subform fields by it`s fieldset
 */
extract($displayData);

$data = $displayData;
		/****************** ACUÉRDATE DE BORRAR ESTAS LINEAS ******************/
		//echo '<pre>'; print_r($data);echo '</pre>';jexit();
?>
	<table class="table table-striped">
		<thead>
			<tr>
				<th class="center" width="5%">Idioma</th>
				<th class="left">Prioridad</th>
				<th class="left">Traductor</th>
				<th class="nowrap center" width="5%">Al traductor</th>
				<th class="left">Archivo traducido</th>
				<th class="left">Importe</th>
				<th class="nowrap center">Al cliente</th>
				<th class="left">Precio</th>
				<th class="left">Importe</th>
			</tr>
		</thead>
		<tr>
			<td>
				<div class="input-group input-sm">
					<label>
						Austríaco
					</label>
				</div>
			</td>
			<td >
				<select name="pais" id="pais" class="form-control input-sm">
					<option value="">Selec. prioridad</option>
					<option value="1">Normal</option>
					<option value="2">Urgente</option>
					<option value="3">Muy Urgente</option>
				</select>
			</td>
			<td>
				<select name="pais" id="pais" class="form-control input-sm">
					<option value="">Selec. traductor</option>
					<option value="1">Pepito de los Palotes</option>
					<option value="2">Esther la de Covalingua</option>
					<option value="3">Nosotros mismos</option>
				</select>
			</td>
			<td>
				<button class="btn btn-success btn-sm"><span class="glyphicon glyphicon-send" aria-hidden="true"></span> Enviar</button>
			</td>
			<td>
				<a href="#">
					<div class="input-group">
						<input type="file" class="form-control input-sm">
						<div class="input-group-addon">
							<span class="glyphicon glyphicon-open" aria-hidden="true"></span>
						</div>
					</div>
				</a>
			</td>
			<td>
				<input type="text" class="form-control input-sm">
			</td>
			<td>
				<button class="btn btn-primary naranja btn-sm">
					<span class="glyphicon glyphicon-send" aria-hidden="true"></span>
					 Enviar
				</button>
			</td>
			<td>
				<input type="text" class="form-control input-sm">
			</td>
			<td>
				<input type="text" class="form-control input-sm" disabled>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-sm">

					<label>
						Alemán
					</label>
				</div>
			</td>
			<td>
				<select name="pais" id="pais" class="form-control input-sm">
					<option value="">Selec. prioridad</option>
					<option value="1">Normal</option>
					<option value="2">Urgente</option>
					<option value="3">Muy Urgente</option>
				</select>
			</td>
			<td>
				<select name="pais" id="pais" class="form-control input-sm">
					<option value="">Selec. traductor</option>
					<option value="1">Pepito de los Palotes</option>
					<option value="2">Esther la de Covalingua</option>
					<option value="3">Nosotros mismos</option>
				</select>
			</td>
			<td>
				<button class="btn btn-success btn-sm"><span class="glyphicon glyphicon-send" aria-hidden="true"></span> Enviar</button>
			</td>
			<td>
				<a href="#">
					<div class="input-group">
						<input type="file" class="form-control input-sm">
						<div class="input-group-addon">
							<span class="glyphicon glyphicon-open" aria-hidden="true"></span>
						</div>
					</div>
				</a>
			</td>
			<td>
				<input type="text" class="form-control input-sm">
			</td>
			<td>
				<button class="btn btn-primary naranja btn-sm">
					<span class="glyphicon glyphicon-send" aria-hidden="true"></span>
					 Enviar
				</button>
			</td>
			<td>
				<input type="text" class="form-control input-sm">
			</td>
			<td>
				<input type="text" class="form-control input-sm" disabled>
			</td>
		</tr>
	</table>

