<?php

use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Uri\Uri;

$data = $displayData;
$translation_subtotal = 0;
$other_subtotal = 0;

?>
	<div style="font-family: Helvetica; font-size: 12px;">
		<table width="100%">
			<tbody>
				<tr>
					<td valign="top" width="50%"><img src="<?php echo $data->company_logo; ?>" alt="Logotipo" width="250" /><br /> <br />
						<table class="dl-table">
							<tbody>
								<tr>
									<td class="invoice_label" valign="top"><?php echo Text::_('COM_ORTRANSLATOR_PDF_FROM'); ?></td>
									<td valign="top"><strong><?php echo $data->from_name; ?></strong></td>
								</tr>
								<tr>
									<td class="invoice_label" valign="top"><?php echo Text::_('COM_ORTRANSLATOR_PDF_ADDRESS'); ?></td>
									<td valign="top">
										<address>
											<?php echo $data->from_address_1; ?><br><?php echo $data->from_address_2; ?><br><?php echo $data->from_zipcode; ?> <?php echo $data->from_city; ?><br><?php echo $data->from_state; ?> <?php echo $data->from_country; ?>
										</address>
									</td>
								<tr>
									<td class="invoice_label" valign="top"><?php echo Text::_('COM_ORTRANSLATOR_PDF_EMAIL'); ?></td>
									<td valign="top"><?php echo $data->from_email; ?></td>
								</tr>
								<tr>
									<td class="invoice_label" valign="top"><?php echo Text::_('COM_ORTRANSLATOR_PDF_FISCAL_NUMBER'); ?></td>
									<td valign="top"><?php echo $data->from_num; ?></td>
								</tr>
							</tbody>
						</table>

						<br />


					</td>
					<td valign="top" width="50%">
						<h1 style="text-align: right;"><?php echo Text::_('COM_ORTRANSLATOR_PDF_'.$data->type); ?></h1>
						<div class="well well-small">
							<table class="dl-table">
								<tbody>
									<tr>
										<td class="invoice_label" valign="top"><?php echo Text::_('COM_ORTRANSLATOR_PDF_'.$data->type.'_NUM'); ?></td>
										<td valign="top"><?php echo $data->title; ?></td>
									</tr>
									<tr>
										<td class="invoice_label" valign="top"><?php echo Text::_('COM_ORTRANSLATOR_PDF_INVOICE_DATE'); ?></td>
										<td valign="top" style="padding-bottom: 16px;"><?php echo $data->document_date; ?></td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="well well-small">
							<table class="dl-table">
								<tbody>
									<tr>
										<td class="invoice_label" valign="top"><?php echo Text::_('COM_ORTRANSLATOR_PDF_BILL_TO'); ?></td>
										<td valign="top"><strong><?php echo $data->to_name ;?></strong></td>
									</tr>
									<tr>
										<td class="invoice_label" valign="top"><?php echo Text::_('COM_ORTRANSLATOR_PDF_ADDRESS'); ?></td>
										<td valign="top"><address> <?php echo $data->to_address ;?> <br /> <?php echo $data->to_zipcode; ?> <?php echo $data->to_city; ?> <br /> <?php echo $data->to_state; ?> <?php echo $data->to_country ;?></address></td>
									</tr>
									<tr>
										<td class="invoice_label" valign="top"><?php echo Text::_('COM_ORTRANSLATOR_PDF_EMAIL'); ?></td>
										<td valign="top"><?php echo $data->to_email ;?></td>
									</tr>
									<tr>
										<td class="invoice_label" valign="top"><?php echo Text::_('COM_ORTRANSLATOR_PDF_VATID'); ?></td>
										<td valign="top"><?php echo $data->to_vatid ;?></td>
									</tr>
									<tr>
										<td class="invoice_label" valign="top"><?php echo Text::_('COM_ORTRANSLATOR_PDF_PHONE'); ?></td>
										<td valign="top"><?php echo $data->to_phone ;?></td>
									</tr>
								</tbody>
							</table>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
		<p class="invoice_header uk-text-bold"><?php echo Text::_('COM_ORTRANSLATOR_PDF_ITEMS'); ?></p>
		<table class="table table-striped" width="100%">
			<thead>
				<tr>
					<th align="left"><?php echo Text::_('COM_ORTRANSLATOR_PDF_DESCRIPTION'); ?></th>
					<th style="text-align: left;" align="left"><?php echo Text::_('COM_ORTRANSLATOR_PDF_ORIGIN'); ?></th>
					<th style="text-align: left;" align="left"><?php echo Text::_('COM_ORTRANSLATOR_PDF_DESTINATION'); ?></th>
					<th style="text-align: left;" align="left"><?php echo Text::_('COM_ORTRANSLATOR_PDF_UNITS'); ?></th>
					<th style="text-align: right;" align="right"><?php echo Text::_('COM_ORTRANSLATOR_PDF_QUANTITY'); ?></th>
					<th style="text-align: right;" align="right"><?php echo Text::_('COM_ORTRANSLATOR_PDF_UNIT_COST'); ?></th>
					<th style="text-align: right;" align="right"><?php echo Text::_('COM_ORTRANSLATOR_PDF_DISCOUNT'); ?></th>
					<th style="text-align: right;" align="right"><?php echo Text::_('COM_ORTRANSLATOR_PDF_PRICE'); ?></th>
				</tr>
			</thead>
			<tbody>
				<!--TRANSLATION ITEMS-->

				<?php foreach ($data->translation_lines as $line => $value) { ?>
				<tr>
					<td><strong><?php echo $value->concept; ?></strong><br /><?php echo $value->from_language; ?> - <?php echo $value->to_language; ?></td>
					<td style="text-align: left;" align="left"><?php echo $value->from_tags; ?></td>
					<td style="text-align: left;" align="left"><?php echo $value->to_tags; ?></td>
					<td style="text-align: left;" align="left"><?php echo $value->units; ?></td>
					<td style="text-align: right;" align="right"><?php echo number_format($value->amount,0,",","."); ?></td>
					<td style="text-align: right;" align="right"><?php echo ClientHelpersClient::formatCurrency(number_format($value->price, 3, ",", ".")); ?></td>
					<td style="text-align: right;" align="right"></td>
					<td style="text-align: right;" align="right"><?php echo ClientHelpersClient::formatCurrency(number_format($value->total, 2, ",", ".")); ?></td>
				</tr>
				<?php
					$translation_subtotal += $value->total;
				} ?>
				<!--/TRANSLATION ITEMS-->
			</tbody>
			<?php $subtotal = $translation_subtotal + $other_subtotal; ?>
			<tfoot>
				<tr>
					<td colspan="4"> </td>
					<td style="text-align: right;" colspan="3" align="right"><?php echo Text::_('COM_ORTRANSLATOR_PDF_DISCOUNT'); ?></td>
					<td style="text-align: right;" align="right">{discount}</td>
				</tr>
				<tr>
					<td colspan="4"> </td>
					<td style="text-align: right;" colspan="3" align="right"><?php echo Text::_('COM_ORTRANSLATOR_PDF_SUBTOTAL'); ?></td>
					<td style="text-align: right;" align="right"><?php echo ClientHelpersClient::formatCurrency(number_format($subtotal, 2, ",", ".")); ?></td>
				</tr>
				<!--GROUPED_TAXES-->
				<?php $iva = floatval($data->iva)/100; ?>
				<?php $taxAmount = $subtotal * $iva; ?>
				<tr>
					<td colspan="4"> </td>
					<td style="text-align: right;" colspan="3" align="right"><?php echo Text::_('COM_ORTRANSLATOR_PDF_TAX_NAME') ?> (<?php echo $data->iva; ?> % <?php echo Text::_('COM_ORTRANSLATOR_PDF_OF'); ?> <strong><?php echo  number_format($subtotal, 2,  ",", "."); ?></strong>)</td>
					<td style="text-align: right;" align="right"><?php echo ClientHelpersClient::formatCurrency(number_format($taxAmount, 2,  ",", ".")); ?></td>
				</tr>
				<!--/GROUPED_TAXES-->
				<?php $total = $subtotal + $taxAmount; ?>
				<tr>
					<td colspan="4"> </td>
					<td style="text-align: right;" colspan="3" align="right"><strong><?php echo Text::_('COM_ORTRANSLATOR_PDF_TOTAL'); ?></strong></td>
					<td style="text-align: right;" align="right"><strong><?php echo ClientHelpersClient::formatCurrency(number_format($total, 2,  ",", ".")); ?></strong></td>
				</tr>
			</tfoot>
		</table>
		<div style="padding: 2px;"><?php echo Text::_('COM_ORTRANSLATOR_PDF_NOTES'); ?></div>
		<div class="muted" style="border-top: 1px solid #000; padding: 2px;"><small>{notes}</small></div>
	</div>