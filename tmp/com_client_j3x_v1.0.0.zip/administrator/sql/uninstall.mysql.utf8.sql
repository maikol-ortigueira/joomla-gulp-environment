DROP TABLE IF EXISTS `#__clients`;
DROP TABLE IF EXISTS `#__client_translations`;
DROP TABLE IF EXISTS `#__client_translators`;
DROP TABLE IF EXISTS `#__client_invoices`;
DROP TABLE IF EXISTS `#__client_quotes`;
DROP TABLE IF EXISTS `#__client_languages`;
DROP TABLE IF EXISTS `#__client_conditions`;
DROP TABLE IF EXISTS `#__client_email_templates`;
