CREATE TABLE IF NOT EXISTS `#__clients` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',
`ordering` INT(11)  NOT NULL ,
`state` TINYINT(1)  NOT NULL ,
`checked_out` INT(11)  NOT NULL ,
`checked_out_time` DATETIME NOT NULL ,
`created_by` INT(11)  NOT NULL ,
`modified_by` INT(11)  NOT NULL ,
`customer_num` int(11) NOT NULL,
`name` VARCHAR(255)  NOT NULL ,
`cif` VARCHAR(15)  NOT NULL ,
`alias` VARCHAR(255) COLLATE utf8_bin NOT NULL ,
`catid` TEXT NOT NULL ,
`adrress` VARCHAR(255)  NOT NULL ,
`cp` VARCHAR(10)  NOT NULL ,
`city` VARCHAR(255)  NOT NULL ,
`estate` VARCHAR(255)  NOT NULL ,
`country` VARCHAR(255)  NOT NULL ,
`email` VARCHAR(255)  NOT NULL ,
`tlf` VARCHAR(20)  NOT NULL ,
`inv_other` TINYINT(1)  NOT NULL ,
`inv_adrress` VARCHAR(255)  NOT NULL ,
`inv_cp` VARCHAR(10)  NOT NULL ,
`inv_city` VARCHAR(255)  NOT NULL ,
`inv_estate` VARCHAR(255)  NOT NULL ,
`inv_country` VARCHAR(255)  NOT NULL ,
`inv_email` VARCHAR(255)  NOT NULL ,
`contact_name` VARCHAR(255)  NOT NULL ,
`contact_position` VARCHAR(255)  NOT NULL ,
`contacte_mail` VARCHAR(255)  NOT NULL ,
`contact_tlf` VARCHAR(20)  NOT NULL ,
`send_translations` TINYINT(1)  NOT NULL ,
`users_id` TEXT NOT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__client_translations` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',

`ordering` INT(11)  NOT NULL ,
`state` TINYINT(1)  NOT NULL ,
`checked_out` INT(11)  NOT NULL ,
`checked_out_time` DATETIME NOT NULL ,
`created_by` INT(11)  NOT NULL ,
`modified_by` INT(11)  NOT NULL ,
`uploaded_file` TEXT NOT NULL ,
`client_id` INT NOT NULL ,
`words` INT(11) NOT NULL ,
`words_checked` TINYINT(1) NOT NULL ,
`quote_id` TEXT NOT NULL ,
`origin_filename` VARCHAR(255)  NOT NULL ,
`filename` VARCHAR(255) COLLATE utf8_bin NOT NULL ,
`uploaded_date` DATETIME NOT NULL ,
`lines` TEXT NOT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__client_translators` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',

`ordering` INT(11)  NOT NULL ,
`state` TINYINT(1)  NOT NULL ,
`checked_out` INT(11)  NOT NULL ,
`checked_out_time` DATETIME NOT NULL ,
`created_by` INT(11)  NOT NULL ,
`modified_by` INT(11)  NOT NULL ,
`name` VARCHAR(255)  NOT NULL ,
`alias` VARCHAR(255) COLLATE utf8_bin NOT NULL ,
`cif` VARCHAR(15)  NOT NULL ,
`adrress` VARCHAR(255)  NOT NULL ,
`cp` VARCHAR(10)  NOT NULL ,
`city` VARCHAR(255)  NOT NULL ,
`estate` VARCHAR(255)  NOT NULL ,
`email` VARCHAR(255)  NOT NULL ,
`tlf` VARCHAR(20)  NOT NULL ,
`contact_name` VARCHAR(255)  NOT NULL ,
`contact_position` VARCHAR(255)  NOT NULL ,
`contacte_mail` VARCHAR(255)  NOT NULL ,
`contact_tlf` VARCHAR(20)  NOT NULL ,
`send_translations_to` TINYINT(1)  NOT NULL ,
`language_id` TEXT NOT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__client_invoices` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',

`ordering` INT(11)  NOT NULL ,
`state` TINYINT(1)  NOT NULL ,
`checked_out` INT(11)  NOT NULL ,
`checked_out_time` DATETIME NOT NULL ,
`created_by` INT(11)  NOT NULL ,
`modified_by` INT(11)  NOT NULL ,
`client_id` INT NOT NULL ,
`invoice_date` DATETIME NOT NULL ,
`invoice_num` VARCHAR(255)  NOT NULL ,
`quote_id` TEXT NOT NULL ,
`title` VARCHAR(255)  NOT NULL ,
`pdf_done` VARCHAR(255)  NOT NULL ,
`pdf_file` VARCHAR(255)  NOT NULL ,
`client_data` TEXT NOT NULL ,
`invoice_translation_lines` TEXT NOT NULL ,
`terms` TEXT NOT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__client_quotes` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',
`ordering` INT(11)  NOT NULL ,
`state` TINYINT(1)  NOT NULL ,
`checked_out` INT(11)  NOT NULL ,
`checked_out_time` DATETIME NOT NULL ,
`created_by` INT(11)  NOT NULL ,
`modified_by` INT(11)  NOT NULL ,
`client_id` INT NOT NULL ,
`quote_date` DATETIME NOT NULL ,
`quote_num` INT(11)  NOT NULL ,
`quote_num_text` VARCHAR(60)  NOT NULL ,
`title` VARCHAR(255)  NOT NULL ,
`pdf_done` VARCHAR(255)  NOT NULL ,
`pdf_file` VARCHAR(255)  NOT NULL ,
`client_data` TEXT NOT NULL ,
`quote_translation_lines` TEXT NOT NULL ,
`terms` TEXT NOT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__client_languages` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',

`ordering` INT(11)  NOT NULL ,
`state` TINYINT(1)  NOT NULL ,
`checked_out` INT(11)  NOT NULL ,
`checked_out_time` DATETIME NOT NULL ,
`created_by` INT(11)  NOT NULL ,
`modified_by` INT(11)  NOT NULL ,
`language_from` VARCHAR(255)  NOT NULL ,
`country_from` VARCHAR(255)  NOT NULL ,
`tag_from` VARCHAR(255)  NOT NULL ,
`language_to` VARCHAR(255)  NOT NULL ,
`country_to` VARCHAR(255)  NOT NULL ,
`tag_to` VARCHAR(255)  NOT NULL ,
`composed_tag` VARCHAR(255)  NOT NULL ,
`price_1` FLOAT(11)  NOT NULL ,
`price_2` FLOAT(11)  NOT NULL ,
`price_3` FLOAT(11)  NOT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__client_conditions` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',
`ordering` INT(11)  NOT NULL ,
`state` TINYINT(1)  NOT NULL ,
`checked_out` INT(11)  NOT NULL ,
`checked_out_time` DATETIME NOT NULL ,
`created_by` INT(11)  NOT NULL ,
`modified_by` INT(11)  NOT NULL ,
`title` VARCHAR(255)  NOT NULL ,
`assignment` INT(11)  NOT NULL ,
`term` TEXT  NOT NULL ,
`termino` INT(11)  NOT NULL ,

PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__client_email_templates` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',
`ordering` INT(11)  NOT NULL ,
`state` TINYINT(1)  NOT NULL ,
`checked_out` INT(11)  NOT NULL ,
`checked_out_time` DATETIME NOT NULL ,
`created_by` INT(11)  NOT NULL ,
`modified_by` INT(11)  NOT NULL ,
`title` VARCHAR(255)  NOT NULL ,
`subject` VARCHAR(255)  NOT NULL ,
`email_content` TEXT  NOT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;



