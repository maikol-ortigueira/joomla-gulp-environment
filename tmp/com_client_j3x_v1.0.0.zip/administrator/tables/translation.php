<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Access\Access;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Table\Table;

/**
 * translation Table class
 *
 * @since  1.6
 */
class ClientTabletranslation extends \Joomla\CMS\Table\Table
{
	/**
	 * Check if a field is unique
	 *
	 * @param   string  $field  Name of the field
	 *
	 * @return bool True if unique
	 */
	private function isUnique ($field)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query
			->select($db->quoteName($field))
			->from($db->quoteName($this->_tbl))
			->where($db->quoteName($field) . ' = ' . $db->quote($this->$field))
			->where($db->quoteName('id') . ' <> ' . (int) $this->{$this->_tbl_key});

		$db->setQuery($query);
		$db->execute();

		return ($db->getNumRows() == 0) ? true : false;
	}

	/**
	 * Constructor
	 *
	 * @param   JDatabase  &$db  A database connector object
	 */
	public function __construct(&$db)
	{
		JObserverMapper::addObserverClassToClass('JTableObserverContenthistory', 'ClientTabletranslation', array('typeAlias' => 'com_client.translation'));
		parent::__construct('#__client_translations', 'id', $db);
        $this->setColumnAlias('published', 'state');
    }

	/**
	 * Overloaded bind function to pre-process the params.
	 *
	 * @param   array  $array   Named array
	 * @param   mixed  $ignore  Optional array or list of parameters to ignore
	 *
	 * @return  null|string  null is operation was satisfactory, otherwise returns an error
	 *
	 * @see     JTable:bind
	 * @since   1.5
     * @throws Exception
	 */
	public function bind($array, $ignore = '')
	{
	    $date = Factory::getDate();
		$task = Factory::getApplication()->input->get('task');

		$input = JFactory::getApplication()->input;
		$task = $input->getString('task', '');

		if ($array['id'] == 0 && empty($array['created_by']))
		{
			$array['created_by'] = JFactory::getUser()->id;
		}

		if ($array['id'] == 0 && empty($array['modified_by']))
		{
			$array['modified_by'] = JFactory::getUser()->id;
		}

		if ($task == 'apply' || $task == 'save')
		{
			$array['modified_by'] = JFactory::getUser()->id;
		}

		// Support for multi file field: uploaded_file
		if (!empty($array['uploaded_file']))
		{
			if (is_array($array['uploaded_file']))
			{
				$array['uploaded_file'] = implode(',', $array['uploaded_file']);
			}
			elseif (strpos($array['uploaded_file'], ',') != false)
			{
				$array['uploaded_file'] = explode(',', $array['uploaded_file']);
			}

			$filename = JPATH_ROOT . '/translations/' . $array['uploaded_file'];

			if (empty($array['words']))
			{
				$array['words'] = WordsCounterHelper::getWords($filename);
			}
		}
		else
		{
			$array['uploaded_file'] = '';
		}



		// Support for multiple or not foreign key field: client_id
		if(!empty($array['client_id']))
		{
			if(is_array($array['client_id'])){
				$array['client_id'] = implode(',',$array['client_id']);
			}
			else if(strrpos($array['client_id'], ',') != false){
				$array['client_id'] = explode(',',$array['client_id']);
			}
		}
		else {
			$array['client_id'] = '';
		}

		// Support for multiple field: quote_id
		if (isset($array['quote_id']))
		{
			if (is_array($array['quote_id']))
			{
				$array['quote_id'] = implode(',',$array['quote_id']);
			}
			elseif (strpos($array['quote_id'], ',') != false)
			{
				$array['quote_id'] = explode(',',$array['quote_id']);
			}
			elseif (strlen($array['quote_id']) == 0)
			{
				$array['quote_id'] = '';
			}
		}
		else
		{
			$array['quote_id'] = '';
		}

		// Support for field: filename
		if (empty($array['filename']))
		{
			$nameData = array('client_id'=>$array['client_id'], 'view'=>'translation');
			$array['filename'] = ClientHelper::getRefName($nameData);
			$prefix = 'texto';
			$long = 4;
			$client = str_pad($array['client_id'],$long,"0", STR_PAD_LEFT).'-';
			$prefix = $prefix.'-';

			if (empty($array['client_id']))
			{
				$array['filename'] = $prefix.JFilterOutput::stringURLSafe(date('Y-m-d H:i:s'));
			}
			else
			{
				$prefix = $client.$prefix;

				$array['filename'] = $prefix.JFilterOutput::stringURLSafe(date('Y-m-d'));
			}

		}

		// Support for empty date field: uploaded_date
		if($array['uploaded_date'] == '0000-00-00' )
		{
			$array['uploaded_date'] = '';
		}

		if (isset($array['params']) && is_array($array['params']))
		{
			$registry = new JRegistry;
			$registry->loadArray($array['params']);
			$array['params'] = (string) $registry;
		}

		if (isset($array['metadata']) && is_array($array['metadata']))
		{
			$registry = new JRegistry;
			$registry->loadArray($array['metadata']);
			$array['metadata'] = (string) $registry;
		}

		if (!Factory::getUser()->authorise('core.admin', 'com_client.translation.' . $array['id']))
		{
			$actions         = Access::getActionsFromFile(
				JPATH_ADMINISTRATOR . '/components/com_client/access.xml',
				"/access/section[@name='translation']/"
			);
			$default_actions = Access::getAssetRules('com_client.translation.' . $array['id'])->getData();
			$array_jaccess   = array();

			foreach ($actions as $action)
			{
                if (key_exists($action->name, $default_actions))
                {
                    $array_jaccess[$action->name] = $default_actions[$action->name];
                }
			}

			$array['rules'] = $this->JAccessRulestoArray($array_jaccess);
		}

		// Bind the rules for ACL where supported.
		if (isset($array['rules']) && is_array($array['rules']))
		{
			$this->setRules($array['rules']);
		}

		return parent::bind($array, $ignore);
	}

	/**
	 * This function convert an array of JAccessRule objects into an rules array.
	 *
	 * @param   array  $jaccessrules  An array of JAccessRule objects.
	 *
	 * @return  array
	 */
	private function JAccessRulestoArray($jaccessrules)
	{
		$rules = array();

		foreach ($jaccessrules as $action => $jaccess)
		{
			$actions = array();

			if ($jaccess)
			{
				foreach ($jaccess->getData() as $group => $allow)
				{
					$actions[$group] = ((bool)$allow);
				}
			}

			$rules[$action] = $actions;
		}

		return $rules;
	}

	/**
	 * Overloaded check function
	 *
	 * @return bool
	 */
	public function check()
	{
		// If there is an ordering column and this is a new row then get the next ordering value
		if (property_exists($this, 'ordering') && $this->id == 0)
		{
			$this->ordering = self::getNextOrder();
		}

		// Check if filename is unique
		if (!$this->isUnique('filename'))
		{
			$count = 0;
			$currentAlias =  $this->filename;
			while(!$this->isUnique('filename')){
				$this->filename = $currentAlias . '-' . $count++;
			}
		}

		// Support multi file field: uploaded_file
		$app = JFactory::getApplication();
		$files = $app->input->files->get('jform', array(), 'raw');
		$array = $app->input->get('jform', array(), 'ARRAY');

		// Support for subform field lines

		if (is_array($this->lines))
		{
			$this->lines = json_encode($this->lines);
		}

		if ($files['uploaded_file']['size'] > 0)
		{
			// Deleting existing files
			$oldFiles = ClientHelper::getFiles($this->id, $this->_tbl, 'uploaded_file');

			foreach ($oldFiles as $f)
			{
				$oldFile = JPATH_ROOT . '/translations/' . $f;

				if (file_exists($oldFile) && !is_dir($oldFile))
				{
					unlink($oldFile);
				}
			}

			$this->uploaded_file = "";

			$singleFile = $files['uploaded_file'];

			jimport('joomla.filesystem.file');
			// Check if the server found any error.
			$fileError = $singleFile['error'];
			$message = '';

			if ($fileError > 0 && $fileError != 4)
			{
				switch ($fileError)
				{
					case 1:
						$message = JText::_('File size exceeds allowed by the server');
						break;
					case 2:
						$message = JText::_('File size exceeds allowed by the html form');
						break;
					case 3:
						$message = JText::_('Partial upload error');
						break;
				}

				if ($message != '')
				{
					$app->enqueueMessage($message, 'warning');

					return false;
				}
			}
			elseif ($fileError == 4)
			{
				if (isset($array['uploaded_file']))
				{
					$this->uploaded_file = $array['uploaded_file'];
				}
			}
			else
			{
				// Check for filesize
				$fileSize = $singleFile['size'];

				if ($fileSize > 2097152)
				{
					$app->enqueueMessage('File bigger than 2MB', 'warning');

					return false;
				}

				// Replace any special characters in the filename
				jimport('joomla.filesystem.file');
				$filename = JFile::stripExt($singleFile['name']);
		$this->origin_filename = $filename;
				$extension = JFile::getExt($singleFile['name']);
				$filename = preg_replace("/[^A-Za-z0-9]/i", "-", $filename);
				$filename = $this->filename . '.' . $extension;
				$uploadPath = JPATH_ROOT . '/translations/' . $filename;
				$fileTemp = $singleFile['tmp_name'];

				if (!JFile::exists($uploadPath))
				{
					if (!JFile::upload($fileTemp, $uploadPath))
					{
						$app->enqueueMessage('Error moving file', 'warning');

						return false;
					}
				}

				$this->uploaded_file .= (!empty($this->uploaded_file)) ? "," : "";
				$this->uploaded_file .= $filename;
			}
		}
		else
		{
			$this->uploaded_file .= $array['uploaded_file_hidden'];
		}


		return parent::check();
	}

	/**
	 * Method to set the publishing state for a row or list of rows in the database
	 * table.  The method respects checked out rows by other users and will attempt
	 * to checkin rows that it can after adjustments are made.
	 *
	 * @param   mixed    $pks     An optional array of primary key values to update.  If not
	 *                            set the instance property value is used.
	 * @param   integer  $state   The publishing state. eg. [0 = unpublished, 1 = published]
	 * @param   integer  $userId  The user id of the user performing the operation.
	 *
	 * @return   boolean  True on success.
	 *
	 * @since    1.0.4
	 *
	 * @throws Exception
	 */
	public function publish($pks = null, $state = 1, $userId = 0)
	{
		// Initialise variables.
		$k = $this->_tbl_key;

		// Sanitize input.
		ArrayHelper::toInteger($pks);
		$userId = (int) $userId;
		$state  = (int) $state;

		// If there are no primary keys set check to see if the instance key is set.
		if (empty($pks))
		{
			if ($this->$k)
			{
				$pks = array($this->$k);
			}
			// Nothing to set publishing state on, return false.
			else
			{
				throw new Exception(500, Text::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'));
			}
		}

		// Build the WHERE clause for the primary keys.
		$where = $k . '=' . implode(' OR ' . $k . '=', $pks);

		// Determine if there is checkin support for the table.
		if (!property_exists($this, 'checked_out') || !property_exists($this, 'checked_out_time'))
		{
			$checkin = '';
		}
		else
		{
			$checkin = ' AND (checked_out = 0 OR checked_out = ' . (int) $userId . ')';
		}

		// Update the publishing state for rows with the given primary keys.
		$this->_db->setQuery(
			'UPDATE `' . $this->_tbl . '`' .
			' SET `state` = ' . (int) $state .
			' WHERE (' . $where . ')' .
			$checkin
		);
		$this->_db->execute();

		// If checkin is supported and all rows were adjusted, check them in.
		if ($checkin && (count($pks) == $this->_db->getAffectedRows()))
		{
			// Checkin each row.
			foreach ($pks as $pk)
			{
				$this->checkin($pk);
			}
		}

		// If the JTable instance value is in the list of primary keys that were set, set the instance.
		if (in_array($this->$k, $pks))
		{
			$this->state = $state;
		}

		return true;
	}

	/**
	 * Define a namespaced asset name for inclusion in the #__assets table
	 *
	 * @return string The asset name
	 *
	 * @see Table::_getAssetName
	 */
	protected function _getAssetName()
	{
		$k = $this->_tbl_key;

		return 'com_client.translation.' . (int) $this->$k;
	}

	/**
	 * Returns the parent asset's id. If you have a tree structure, retrieve the parent's id using the external key field
	 *
	 * @param   JTable   $table  Table name
	 * @param   integer  $id     Id
	 *
	 * @see Table::_getAssetParentId
	 *
	 * @return mixed The id on success, false on failure.
	 */
	protected function _getAssetParentId(JTable $table = null, $id = null)
	{
		// We will retrieve the parent-asset from the Asset-table
		$assetParent = Table::getInstance('Asset');

		// Default: if no asset-parent can be found we take the global asset
		$assetParentId = $assetParent->getRootId();

		// The item has the component as asset-parent
		$assetParent->loadByName('com_client');

		// Return the found asset-parent-id
		if ($assetParent->id)
		{
			$assetParentId = $assetParent->id;
		}

		return $assetParentId;
	}

	/**
	 * Delete a record by id
	 *
	 * @param   mixed  $pk  Primary key value to delete. Optional
	 *
	 * @return bool
	 */
	public function delete($pk = null)
	{
		$this->load($pk);
		$result = parent::delete($pk);

		if ($result)
		{
			jimport('joomla.filesystem.file');

			$checkImageVariableType = gettype($this->uploaded_file);

			switch ($checkImageVariableType)
			{
			case 'string':
				JFile::delete(JPATH_ROOT . '/translations/' . $this->uploaded_file);
			break;
			default:
			foreach ($this->uploaded_file as $uploaded_fileFile)
			{
				JFile::delete(JPATH_ROOT . '/translations/' . $uploaded_fileFile);
			}
			}
		}

		return $result;
	}
}
