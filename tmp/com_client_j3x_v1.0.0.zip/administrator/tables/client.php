<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Access\Access;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Table\Table;

/**
 * client Table class
 *
 * @since  1.6
 */
class ClientTableclient extends \Joomla\CMS\Table\Table
{
	/**
	 * Check if a field is unique
	 *
	 * @param   string  $field  Name of the field
	 *
	 * @return bool True if unique
	 */
	private function isUnique ($field)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query
			->select($db->quoteName($field))
			->from($db->quoteName($this->_tbl))
			->where($db->quoteName($field) . ' = ' . $db->quote($this->$field))
			->where($db->quoteName('id') . ' <> ' . (int) $this->{$this->_tbl_key});

		$db->setQuery($query);
		$db->execute();

		return ($db->getNumRows() == 0) ? true : false;
	}

	/**
	 * Constructor
	 *
	 * @param   JDatabase  &$db  A database connector object
	 */
	public function __construct(&$db)
	{
		JObserverMapper::addObserverClassToClass('JTableObserverContenthistory', 'ClientTableclient', array('typeAlias' => 'com_client.client'));
		parent::__construct('#__clients', 'id', $db);
        $this->setColumnAlias('published', 'state');
    }

	/**
	 * Overloaded bind function to pre-process the params.
	 *
	 * @param   array  $array   Named array
	 * @param   mixed  $ignore  Optional array or list of parameters to ignore
	 *
	 * @return  null|string  null is operation was satisfactory, otherwise returns an error
	 *
	 * @see     JTable:bind
	 * @since   1.5
     * @throws Exception
	 */
	public function bind($array, $ignore = '')
	{
	    $date = Factory::getDate();
		$task = Factory::getApplication()->input->get('task');

		$input = JFactory::getApplication()->input;
		$task = $input->getString('task', '');

		if ($array['id'] == 0 && empty($array['created_by']))
		{
			$array['created_by'] = JFactory::getUser()->id;
		}

		if ($array['id'] == 0 && empty($array['modified_by']))
		{
			$array['modified_by'] = JFactory::getUser()->id;
		}

		if ($task == 'apply' || $task == 'save')
		{
			$array['modified_by'] = JFactory::getUser()->id;
		}

		// Support for alias field: alias
		if (empty($array['alias']))
		{
			if (empty($array['name']))
			{
				$array['alias'] = JFilterOutput::stringURLSafe(date('Y-m-d H:i:s'));
			}
			else
			{
				if(JFactory::getConfig()->get('unicodeslugs') == 1)
				{
					$array['alias'] = JFilterOutput::stringURLUnicodeSlug(trim($array['name']));
				}
				else
				{
					$array['alias'] = JFilterOutput::stringURLSafe(trim($array['name']));
				}
			}
		}


		// Support for multiple field: catid
		if (isset($array['catid']))
		{
			if (is_array($array['catid']))
			{
				$array['catid'] = implode(',',$array['catid']);
			}
			elseif (strpos($array['catid'], ',') != false)
			{
				$array['catid'] = explode(',',$array['catid']);
			}
			elseif (strlen($array['catid']) == 0)
			{
				$array['catid'] = '';
			}
		}
		else
		{
			$array['catid'] = '';
		}

		// Support for multiple field: estate
		if (isset($array['estate']))
		{
			if (is_array($array['estate']))
			{
				$array['estate'] = implode(',',$array['estate']);
			}
			elseif (strpos($array['estate'], ',') != false)
			{
				$array['estate'] = explode(',',$array['estate']);
			}
			elseif (strlen($array['estate']) == 0)
			{
				$array['estate'] = '';
			}
		}
		else
		{
			$array['estate'] = '';
		}

		// Support for multiple field: country
		if (isset($array['country']))
		{
			if (is_array($array['country']))
			{
				$array['country'] = implode(',',$array['country']);
			}
			elseif (strpos($array['country'], ',') != false)
			{
				$array['country'] = explode(',',$array['country']);
			}
			elseif (strlen($array['country']) == 0)
			{
				$array['country'] = '';
			}
		}
		else
		{
			$array['country'] = '';
		}

		// Support for multiple field: inv_estate
		if (isset($array['inv_estate']))
		{
			if (is_array($array['inv_estate']))
			{
				$array['inv_estate'] = implode(',',$array['inv_estate']);
			}
			elseif (strpos($array['inv_estate'], ',') != false)
			{
				$array['inv_estate'] = explode(',',$array['inv_estate']);
			}
			elseif (strlen($array['inv_estate']) == 0)
			{
				$array['inv_estate'] = '';
			}
		}
		else
		{
			$array['inv_estate'] = '';
		}

		// Support for multiple field: inv_country
		if (isset($array['inv_country']))
		{
			if (is_array($array['inv_country']))
			{
				$array['inv_country'] = implode(',',$array['inv_country']);
			}
			elseif (strpos($array['inv_country'], ',') != false)
			{
				$array['inv_country'] = explode(',',$array['inv_country']);
			}
			elseif (strlen($array['inv_country']) == 0)
			{
				$array['inv_country'] = '';
			}
		}
		else
		{
			$array['inv_country'] = '';
		}

		// Support for multiple or not foreign key field: users_id
			if(!empty($array['users_id']))
			{
				if(is_array($array['users_id'])){
					$array['users_id'] = implode(',',$array['users_id']);
				}
				else if(strrpos($array['users_id'], ',') != false){
					$array['users_id'] = explode(',',$array['users_id']);
				}
			}
			else {
				$array['users_id'] = '';
			}

		if (isset($array['params']) && is_array($array['params']))
		{
			$registry = new JRegistry;
			$registry->loadArray($array['params']);
			$array['params'] = (string) $registry;
		}

		if (isset($array['metadata']) && is_array($array['metadata']))
		{
			$registry = new JRegistry;
			$registry->loadArray($array['metadata']);
			$array['metadata'] = (string) $registry;
		}

		if (!Factory::getUser()->authorise('core.admin', 'com_client.client.' . $array['id']))
		{
			$actions         = Access::getActionsFromFile(
				JPATH_ADMINISTRATOR . '/components/com_client/access.xml',
				"/access/section[@name='client']/"
			);
			$default_actions = Access::getAssetRules('com_client.client.' . $array['id'])->getData();
			$array_jaccess   = array();

			foreach ($actions as $action)
			{
                if (key_exists($action->name, $default_actions))
                {
                    $array_jaccess[$action->name] = $default_actions[$action->name];
                }
			}

			$array['rules'] = $this->JAccessRulestoArray($array_jaccess);
		}

		// Bind the rules for ACL where supported.
		if (isset($array['rules']) && is_array($array['rules']))
		{
			$this->setRules($array['rules']);
		}

		return parent::bind($array, $ignore);
	}

	/**
	 * This function convert an array of JAccessRule objects into an rules array.
	 *
	 * @param   array  $jaccessrules  An array of JAccessRule objects.
	 *
	 * @return  array
	 */
	private function JAccessRulestoArray($jaccessrules)
	{
		$rules = array();

		foreach ($jaccessrules as $action => $jaccess)
		{
			$actions = array();

			if ($jaccess)
			{
				foreach ($jaccess->getData() as $group => $allow)
				{
					$actions[$group] = ((bool)$allow);
				}
			}

			$rules[$action] = $actions;
		}

		return $rules;
	}

	/**
	 * Overloaded check function
	 *
	 * @return bool
	 */
	public function check()
	{
		// If there is an ordering column and this is a new row then get the next ordering value
		if (property_exists($this, 'ordering') && $this->id == 0)
		{
			$this->ordering = self::getNextOrder();
		}

		// If there is an customer_num column and this is a new row then get the next customer_num value
		if (property_exists($this, 'customer_num') && $this->id == 0)
		{
			$this->customer_num = self::getNextCustomerNumber();
		}

		// Check if cif is unique
		if (!$this->isUnique('cif'))
		{
			throw new Exception('Your <b>cif</b> item "<b>' . $this->cif . '</b>" already exists');
		}
		// Check if alias is unique
		if (!$this->isUnique('alias'))
		{
			$count = 0;
			$currentAlias =  $this->alias;
			while(!$this->isUnique('alias')){
				$this->alias = $currentAlias . '-' . $count++;
			}
		}


		return parent::check();
	}

	/**
	 * Method to set the publishing state for a row or list of rows in the database
	 * table.  The method respects checked out rows by other users and will attempt
	 * to checkin rows that it can after adjustments are made.
	 *
	 * @param   mixed    $pks     An optional array of primary key values to update.  If not
	 *                            set the instance property value is used.
	 * @param   integer  $state   The publishing state. eg. [0 = unpublished, 1 = published]
	 * @param   integer  $userId  The user id of the user performing the operation.
	 *
	 * @return   boolean  True on success.
	 *
	 * @since    1.0.4
	 *
	 * @throws Exception
	 */
	public function publish($pks = null, $state = 1, $userId = 0)
	{
		// Initialise variables.
		$k = $this->_tbl_key;

		// Sanitize input.
		ArrayHelper::toInteger($pks);
		$userId = (int) $userId;
		$state  = (int) $state;

		// If there are no primary keys set check to see if the instance key is set.
		if (empty($pks))
		{
			if ($this->$k)
			{
				$pks = array($this->$k);
			}
			// Nothing to set publishing state on, return false.
			else
			{
				throw new Exception(500, Text::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'));
			}
		}

		// Build the WHERE clause for the primary keys.
		$where = $k . '=' . implode(' OR ' . $k . '=', $pks);

		// Determine if there is checkin support for the table.
		if (!property_exists($this, 'checked_out') || !property_exists($this, 'checked_out_time'))
		{
			$checkin = '';
		}
		else
		{
			$checkin = ' AND (checked_out = 0 OR checked_out = ' . (int) $userId . ')';
		}

		// Update the publishing state for rows with the given primary keys.
		$this->_db->setQuery(
			'UPDATE `' . $this->_tbl . '`' .
			' SET `state` = ' . (int) $state .
			' WHERE (' . $where . ')' .
			$checkin
		);
		$this->_db->execute();

		// If checkin is supported and all rows were adjusted, check them in.
		if ($checkin && (count($pks) == $this->_db->getAffectedRows()))
		{
			// Checkin each row.
			foreach ($pks as $pk)
			{
				$this->checkin($pk);
			}
		}

		// If the JTable instance value is in the list of primary keys that were set, set the instance.
		if (in_array($this->$k, $pks))
		{
			$this->state = $state;
		}

		return true;
	}

	/**
	 * Define a namespaced asset name for inclusion in the #__assets table
	 *
	 * @return string The asset name
	 *
	 * @see Table::_getAssetName
	 */
	protected function _getAssetName()
	{
		$k = $this->_tbl_key;

		return 'com_client.client.' . (int) $this->$k;
	}

	/**
	 * Returns the parent asset's id. If you have a tree structure, retrieve the parent's id using the external key field
	 *
	 * @param   JTable   $table  Table name
	 * @param   integer  $id     Id
	 *
	 * @see Table::_getAssetParentId
	 *
	 * @return mixed The id on success, false on failure.
	 */
	protected function _getAssetParentId(JTable $table = null, $id = null)
	{
		// We will retrieve the parent-asset from the Asset-table
		$assetParent = Table::getInstance('Asset');

		// Default: if no asset-parent can be found we take the global asset
		$assetParentId = $assetParent->getRootId();

		// The item has the component as asset-parent
		$assetParent->loadByName('com_client');

		// Return the found asset-parent-id
		if ($assetParent->id)
		{
			$assetParentId = $assetParent->id;
		}

		return $assetParentId;
	}

	/**
	 * Delete a record by id
	 *
	 * @param   mixed  $pk  Primary key value to delete. Optional
	 *
	 * @return bool
	 */
	public function delete($pk = null)
	{
		$this->load($pk);
		$result = parent::delete($pk);

		return $result;
	}


	/**
	 * Method to get the next customer_num value for a group of rows defined by an SQL WHERE clause.
	 *
	 * This is useful for placing a new item last in a group of items in the table.
	 *
	 * @param   string  $where  WHERE clause to use for selecting the MAX(customer_num) for the table.
	 *
	 * @return  integer  The next customer_num value.
	 *
	 * @since   1.7.0
	 * @throws  \UnexpectedValueException
	 */
	public function getNextCustomerNumber($where = '')
	{
		// Check if there is an customer_num field set
		$customer_numField = $this->getColumnAlias('customer_num');

		if (!property_exists($this, $customer_numField))
		{
			throw new \UnexpectedValueException(sprintf('%s does not support customer_num.', get_class($this)));
		}

		// Get the largest customer_num value for a given where clause.
		$query = $this->_db->getQuery(true)
			->select('MAX(' . $this->_db->quoteName($customer_numField) . ')')
			->from($this->_tbl);

		if ($where)
		{
			$query->where($where);
		}

		$this->_db->setQuery($query);
		$max = (int) $this->_db->loadResult();

		// Return the largest customer_num value + 1.
		return $max + 1;
	}
}
