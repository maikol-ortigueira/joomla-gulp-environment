<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;


HTMLHelper::addIncludePath(JPATH_COMPONENT . '/helpers/html');
HTMLHelper::_('behavior.tooltip');
HTMLHelper::_('behavior.formvalidation');
HTMLHelper::_('formbehavior.chosen', 'select');
HTMLHelper::_('behavior.keepalive');

?>
<script type="text/javascript">

	js = jQuery.noConflict();
	js(document).ready(function () {

	js('input:hidden.client_id').each(function(){
		var name = js(this).attr('name');
		if(name.indexOf('client_idhidden')){
			js('#jform_client_id option[value="'+js(this).val()+'"]').attr('selected',true);
		}
	});
	js("#jform_client_id").trigger("liszt:updated");
	js('input:hidden.quote_id').each(function(){
		var name = js(this).attr('name');
		if(name.indexOf('quote_idhidden')){
			js('#jform_quote_id option[value="'+js(this).val()+'"]').attr('selected',true);
		}
	});
	js("#jform_quote_id").trigger("liszt:updated");
	});

	Joomla.submitbutton = function (task) {
		if (task == 'translation.cancel') {
			Joomla.submitform(task, document.getElementById('translation-form'));
		}
		else {

				if (js('#jform_uploaded_file').val() == '' && js('#jform_uploaded_file_hidden').val() == '') {
					alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
					return;
				}
			if (task != 'translation.cancel' && document.formvalidator.isValid(document.id('translation-form'))) {

				Joomla.submitform(task, document.getElementById('translation-form'));
			}
			else {
				alert('<?php echo $this->escape(Text::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
			}
		}
	}
</script>

<form
	action="<?php echo JRoute::_('index.php?option=com_client&layout=edit&id=' . (int) $this->item->id); ?>"
	method="post" enctype="multipart/form-data" name="adminForm" id="translation-form" class="form-validate">

	<input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
	<input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />
	<input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />
	<input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />
	<input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />
	<input type="hidden" name="jform[uploaded_file_hidden]" id="jform_uploaded_file_hidden" value="<?php echo $this->item->uploaded_file; ?>" />
	<?php echo $this->form->renderField('created_by'); ?>
	<?php echo $this->form->renderField('modified_by'); ?>
	<div class="form-inline form-inline-header" style="margin: 20px 10px;">
		<!-- Uploaded file Field -->
		<div class="control-group hide-on-uploaded-file">
			<div class="control-label"><?php echo $this->form->getLabel('uploaded_file'); ?></div>
			<div class="controls"><?php echo $this->form->getInput('uploaded_file'); ?></div>
		</div><!-- End Uploaded file Field -->
		<?php if (!empty($this->item->uploaded_file)) : ?>
			<div class="control-group">
				<div class="control-label">
					<label><strong><?php echo Text::_('COM_ORTRANSLATOR_CLIENT_FIELD_ARCHIVO_LBL'); ?></strong></label>
				</div>
				<div class="controls">
					<a href="<?php echo JRoute::_(JUri::root() . 'translations' . DIRECTORY_SEPARATOR . $this->item->uploaded_file, false);?>" class="large-text"><?php echo $this->item->uploaded_file; ?></a>
				</div>
			</div>
		<?php endif; ?>
		<!-- Words Field -->
		<div class="control-group show_on_file_exists">
			<div class="control-label"><?php echo $this->form->getLabel('words'); ?></div>
			<div class="controls"><?php echo $this->form->getInput('words'); ?></div>
		</div><!-- End Words Field -->
	</div>
	<div class="form-inline form-inline-header" style="margin: 20px 10px;">
		<?php echo $this->form->renderField('client_id'); ?>
	</div>
	<?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'translation')); ?>
	<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'translation', JText::_('COM_ORTRANSLATOR_TAB_TRANSLATION', true)); ?>

	<div class="row-fluid">
		<div class="span9 form-horizontal">
			<fieldset class="adminform">
				<div id="hide_on_file_exists">
					<?php echo $this->form->renderField('sube_archivo'); ?>
				</div>
				<div class="show_on_file_exists">
					<div id="comprobacion_palabras">
						<?php echo $this->form->renderField('comprueba_palabras'); ?>
						<?php echo $this->form->renderField('words_checked'); ?>
					</div>
				</div>
				<div id="palabras_comprobadas">
					<?php echo $this->form->renderField('quote_id'); ?>
					<?php echo $this->form->renderField('origin_filename'); ?>
					<?php echo $this->form->renderField('uploaded_date'); ?>
				</div>
			</fieldset>
		</div>
		<div class="span3">
			<?php echo JLayoutHelper::render('joomla.edit.global', $this); ?>
		</div>
	</div>

	<?php echo JHtml::_('bootstrap.endTab'); ?>

	<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'translations', JText::_('COM_ORTRANSLATOR_TAB_TRANSLATION_TRANSLATIONS', true)); ?>
		<?php echo $this->form->renderField('lines'); ?>
	<?php echo JHtml::_('bootstrap.endTab'); ?>

	<?php if (JFactory::getUser()->authorise('core.admin','client')) : ?>
		<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'permissions', JText::_('JGLOBAL_ACTION_PERMISSIONS_LABEL', true)); ?>
			<?php echo $this->form->getInput('rules'); ?>
		<?php echo JHtml::_('bootstrap.endTab'); ?>
	<?php endif; ?>
	<?php echo JHtml::_('bootstrap.endTabSet'); ?>

	<input type="hidden" name="task" value=""/>
	<?php echo JHtml::_('form.token'); ?>
</form>

<script type="text/javascript">
	// Declaración de variables
	var archivo = "<?php echo $this->item->uploaded_file; ?>"
	var cliente = "<?php echo $this->item->client_id; ?>"
	var wordsChecked = "<?php echo $this->item->words_checked; ?>"

	// Crear un contador de lineas del subform
	jQuery(document).on('subform-row-add', function(event, row) {
		console.log('Número de lineas = ',row.rowIndex);
	})

	// Si no existe archivo mostrar instrucciones
	if (archivo == "") {
		jQuery('.show_on_file_exists').hide();
		jQuery('#traducciones').hide();
		jQuery('#palabras_comprobadas').hide();
	} else {
		// Esconder instrucciones
		jQuery('#hide_on_file_exists').hide();
		jQuery('.hide-on-uploaded-file').hide();

		if (jQuery('#jform_client_id option:selected').val() != "") {
			jQuery('#jform_client_id option:not(:selected)').attr('disabled',true);;
		}

		if (wordsChecked != 1) {
			jQuery('#palabras_comprobadas').hide();
		}
	};

	// Si ya se han comprobado las palabras esconder el checkbox
	if (wordsChecked == 1) {
		jQuery('#comprobacion_palabras').hide();
		jQuery('#palabras_comprobadas').show();
	}

	jQuery(document).on('click',jQuery('#jform_words_checked'), function(){
		if (jQuery('#jform_words_checked').prop('checked') == true) {
			jQuery('#comprobacion_palabras').hide();
			jQuery('#jform_words').attr('readonly', true);
			jQuery('#palabras_comprobadas').show('slow');
		}
	});
	var clientId = jQuery('#jform_client_id').val();
	var quoteId = jQuery('#jform_quote_id').val();

	// Obtener el listado de presupuestos para el cliente
	if (clientId > 0) {
		getQuote(clientId);
	}

	// Cuando se selecciona el idioma establecemos los datos de la linea
	function setLineValues(language) {
		// Prefijo de la linea de traducción
		var idPrefix = getIdPrefix(language.id);
		// Campo del precio de cada línea
		var priceField = jQuery(idPrefix+'translation_price');
		// Campo del precio total de la linea
		var amountField = jQuery(idPrefix+'translation_amount');
		// Campo del selector de traductor para cada línea
		var translatorField = jQuery(idPrefix+'translator_id');
		// Id del lenguage de la linea
		var languageId = language.value;
		// Id del presupuesto del cliente
		var quoteIdValue = jQuery('#jform_quote_id').val();
		// Valor del campo words
		var totalWords = jQuery('#jform_words').val();

		// Recupero el precio por idioma según presupuesto para asignar al campo precio por palabra de la linea
		setNewLineValues(languageId, quoteIdValue, priceField, totalWords, amountField);

		getLangTranslators(languageId, translatorField);
		//jQuery(idPrefix+'translation_amount')
	}

	// Si pulsas el botón de enviar correo a traductor
	function sendMailToTranslator(values) {
		var email_to = jQuery(getIdPrefix(values.id)+'translator_id').val();
		console.log(email_to);
		var table = 'client_translators';
		var email_template = 'send_to_translate';
		var attachment = jQuery('#jform_uploaded_file_hidden').val();
		var language = jQuery(getIdPrefix(values.id)+'language_id').val();
		var data0 = {email_to: email_to, language: language, table: 'client_translators', email_template: email_template, attachment: attachment};

		// Enviar correo vía ajax
		if (sendEmail(data0)) {
			jQuery(getIdPrefix(values.id)+'sended_mail_to_translator').val('1');
			jQuery(getIdPrefix(values.id)+'mail_to_translator-text').show('slow');
			//jQuery(getIdPrefix(values.id)+'mail_to_translator').hide('slow');
			jQuery(getIdPrefix(values.id)+'translated_file-lbl').show('slow');
			jQuery(getIdPrefix(values.id)+'translated_file').show('slow');
		}
	}

	// Si pulsas el botón de enviar correo al cliente
	function sendMailToClient(e) {
		var idPrefix = getIdPrefix(e.id);

		jQuery('#'+e.id).hide('slow');
		jQuery('#'+e.id+'-text').show('slow');
		console.log(lineas);
	}

	// Si modificamos el valor del precio de la palabra en la casilla se genera un nuevo valor para el total de la linea.
	function getTotalAmount(e){
		// Prefijo de la linea de traducción
		var idPrefix = getIdPrefix(e.id);

		var words = jQuery('#jform_words').val();
		var wordPrice = e.value;

		jQuery(idPrefix+'translation_amount').val((words*wordPrice).toFixed(2));
	}

</script>
