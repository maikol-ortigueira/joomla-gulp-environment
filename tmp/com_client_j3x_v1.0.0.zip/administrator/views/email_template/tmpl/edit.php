<?php
/**
 * @version    3.2
 * @package    com_client
 * @author     Maikol Fustes <maikol.ortigueira@gmail.com>
 * @copyright  2019 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;


HTMLHelper::addIncludePath(JPATH_COMPONENT . '/helpers/html');
HTMLHelper::_('behavior.tooltip');
HTMLHelper::_('behavior.formvalidation');
HTMLHelper::_('formbehavior.chosen', 'select');
HTMLHelper::_('behavior.keepalive');

?>

<script type="text/javascript">
	Joomla.submitbutton = function (task) {
		if (task == 'email_template.cancel') {
			Joomla.submitform(task, document.getElementById('email_template-form'));
		}
		else {

			if (task != 'email_template.cancel' && document.formvalidator.isValid(document.id('email_template-form'))) {

				Joomla.submitform(task, document.getElementById('email_template-form'));
			}
			else {
				alert('<?php echo $this->escape(Text::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
			}
		}
	}
</script>

<form
	action="<?php echo JRoute::_('index.php?option=com_client&layout=edit&id=' . (int) $this->item->id); ?>"
	method="post" enctype="multipart/form-data" name="adminForm" id="email_template-form" class="form-validate form-horizontal">

	<input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
	<input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />
	<input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />
	<input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />
	<input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />

	<?php echo $this->form->renderField('created_by'); ?>
	<?php echo $this->form->renderField('modified_by'); ?>
	<?php if(1 == 2) : ?>
	<!-- Start tabs -->
	<?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'email_template')); ?>
		<!-- First tab -->
		<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'email_template', JText::_('COM_ORTRANSLATOR_TAB_EMAIL_TEMPLATE', true)); ?>
	<?php endif; ?>
			<div class="row-fluid">
				<div class="span10 form-horizontal">
					<fieldset class="adminform">
						<legend><?php echo Text::_('Plantilla de Correo electrónico'); ?></legend>
						<?php if(empty($this->item->id)) { ?>
							<?php echo $this->form->renderField('title'); ?>
						<?php } ?>
						<?php echo $this->form->renderField('email_template_tags'); ?>
						<?php echo $this->form->renderField('subject'); ?>
						<?php echo $this->form->renderField('email_content'); ?>
					</fieldset>
				</div>
			</div>
	<?php if(1 == 2) : ?>
		<?php echo JHtml::_('bootstrap.endTab'); ?>
		<!-- End of first tab -->

		<!-- Permissions tab -->
		<?php if (JFactory::getUser()->authorise('core.admin','client')) : ?>
			<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'permissions', JText::_('JGLOBAL_ACTION_PERMISSIONS_LABEL', true)); ?>
				<?php echo $this->form->getInput('rules'); ?>
			<?php echo JHtml::_('bootstrap.endTab'); ?>
		<?php endif; ?>
		<!-- End of permissions tab -->
	<?php echo JHtml::_('bootstrap.endTabSet'); ?>
	<!-- End of all tabs -->
	<?php endif; ?>

	<input type="hidden" name="task" value=""/>
	<?php echo JHtml::_('form.token'); ?>

</form>