<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;


HTMLHelper::addIncludePath(JPATH_COMPONENT . '/helpers/html');
HTMLHelper::_('behavior.tooltip');
HTMLHelper::_('behavior.formvalidation');
HTMLHelper::_('formbehavior.chosen', 'select');
HTMLHelper::_('behavior.keepalive');

// Import CSS
$document = Factory::getDocument();
$document->addStyleSheet(Uri::root() . 'media/com_client/css/form.css');
?>
<script type="text/javascript">
	js = jQuery.noConflict();
	js(document).ready(function () {

	js('input:hidden.language_id').each(function(){
		var name = js(this).attr('name');
		if(name.indexOf('language_idhidden')){
			js('#jform_language_id option[value="'+js(this).val()+'"]').attr('selected',true);
		}
	});
	js("#jform_language_id").trigger("liszt:updated");
	});

	Joomla.submitbutton = function (task) {
		if (task == 'translator.cancel') {
			Joomla.submitform(task, document.getElementById('translator-form'));
		}
		else {

			if (task != 'translator.cancel' && document.formvalidator.isValid(document.id('translator-form'))) {

				Joomla.submitform(task, document.getElementById('translator-form'));
			}
			else {
				alert('<?php echo $this->escape(Text::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
			}
		}
	}
</script>

<form
	action="<?php echo JRoute::_('index.php?option=com_client&layout=edit&id=' . (int) $this->item->id); ?>"
	method="post" enctype="multipart/form-data" name="adminForm" id="translator-form" class="form-validate form-horizontal">


	<input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
	<input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />
	<input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />
	<input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />
	<input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />
	<?php echo $this->form->renderField('created_by'); ?>
	<?php echo $this->form->renderField('modified_by'); ?>
	<?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'translator')); ?>
	<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'translator', JText::_('COM_ORTRANSLATOR_TAB_TRANSLATOR', true)); ?>
	<div class="row-fluid">
		<div class="span8 form-horizontal">
			<fieldset class="adminform">
				<legend><?php echo JText::_('COM_ORTRANSLATOR_FIELDSET_TRANSLATOR'); ?></legend>
				<?php echo $this->form->renderField('name'); ?>
				<?php echo $this->form->renderField('alias'); ?>
				<?php echo $this->form->renderField('cif'); ?>
			</fieldset>
		</div>
		<div class="span4 form-vertical">
			<?php if ($this->state->params->get('save_history', 1)) : ?>
				<fieldset class="adminform">
					<legend><?php echo Text::_('COM_ORTRANSLATOR_FIELDSET_VERSION'); ?></legend>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('version_note'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('version_note'); ?></div>
				</div>
				</fieldset>
			<?php endif; ?>
		</div>
	</div>
	<?php echo JHtml::_('bootstrap.endTab'); ?>
	<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'Datos', JText::_('COM_ORTRANSLATOR_TAB_DATOS', true)); ?>
	<div class="row-fluid">
		<div class="span10 form-horizontal">
			<fieldset class="adminform">
				<legend><?php echo JText::_('COM_ORTRANSLATOR_FIELDSET_DIRECCIN'); ?></legend>
				<?php echo $this->form->renderField('adrress'); ?>
				<?php echo $this->form->renderField('cp'); ?>
				<?php echo $this->form->renderField('city'); ?>
				<?php echo $this->form->renderField('estate'); ?>
				<?php echo $this->form->renderField('email'); ?>
				<?php echo $this->form->renderField('tlf'); ?>
			</fieldset>
		</div>
	</div>
	<?php echo JHtml::_('bootstrap.endTab'); ?>
	<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'Contacto', JText::_('COM_ORTRANSLATOR_TAB_CONTACTO', true)); ?>
	<div class="row-fluid">
		<div class="span10 form-horizontal">
			<fieldset class="adminform">
				<legend><?php echo JText::_('COM_ORTRANSLATOR_FIELDSET_PERSONADECONTACTO'); ?></legend>
				<?php echo $this->form->renderField('contact_name'); ?>
				<?php echo $this->form->renderField('contact_position'); ?>
				<?php echo $this->form->renderField('contacte_mail'); ?>
				<?php echo $this->form->renderField('contact_tlf'); ?>
				<?php echo $this->form->renderField('send_translations_to'); ?>
			</fieldset>
		</div>
	</div>
	<?php echo JHtml::_('bootstrap.endTab'); ?>
	<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'Idiomas', JText::_('COM_ORTRANSLATOR_TAB_IDIOMAS', true)); ?>
	<div class="row-fluid">
		<div class="span10 form-horizontal">
			<fieldset class="adminform">
				<legend><?php echo JText::_('COM_ORTRANSLATOR_FIELDSET_LISTADEIDIOMAS'); ?></legend>
				<?php echo $this->form->renderField('language_id'); ?>
				<?php
				foreach((array)$this->item->language_id as $value)
				{
					if(!is_array($value))
					{
						echo '<input type="hidden" class="language_id" name="jform[language_idhidden]['.$value.']" value="'.$value.'" />';
					}
				}
				?>
			</fieldset>
		</div>
	</div>
	<?php echo JHtml::_('bootstrap.endTab'); ?>

	<?php if (JFactory::getUser()->authorise('core.admin','client')) : ?>
	<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'permissions', JText::_('JGLOBAL_ACTION_PERMISSIONS_LABEL', true)); ?>
		<?php echo $this->form->getInput('rules'); ?>
	<?php echo JHtml::_('bootstrap.endTab'); ?>
<?php endif; ?>
	<?php echo JHtml::_('bootstrap.endTabSet'); ?>

	<input type="hidden" name="task" value=""/>
	<?php echo JHtml::_('form.token'); ?>

</form>
