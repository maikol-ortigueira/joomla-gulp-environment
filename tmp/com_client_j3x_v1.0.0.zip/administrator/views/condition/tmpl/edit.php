<?php
/**
 * @version    3.2
 * @package    com_client
 * @author     Maikol Fustes <maikol.ortigueira@gmail.com>
 * @copyright  2019 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;


HTMLHelper::addIncludePath(JPATH_COMPONENT . '/helpers/html');
HTMLHelper::_('behavior.tooltip');
HTMLHelper::_('behavior.formvalidation');
HTMLHelper::_('formbehavior.chosen', 'select');
HTMLHelper::_('behavior.keepalive');

?>

<script type="text/javascript">
	Joomla.submitbutton = function (task) {
		if (task == 'condition.cancel') {
			Joomla.submitform(task, document.getElementById('condition-form'));
		}
		else {

			if (task != 'condition.cancel' && document.formvalidator.isValid(document.id('condition-form'))) {

				Joomla.submitform(task, document.getElementById('condition-form'));
			}
			else {
				alert('<?php echo $this->escape(Text::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
			}
		}
	}
</script>

<form
	action="<?php echo JRoute::_('index.php?option=com_client&layout=edit&id=' . (int) $this->item->id); ?>"
	method="post" enctype="multipart/form-data" name="adminForm" id="condition-form" class="form-validate form-horizontal">

	<input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
	<input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />
	<input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />
	<input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />
	<input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />

	<?php echo $this->form->renderField('created_by'); ?>
	<?php echo $this->form->renderField('modified_by'); ?>

	<!-- Start tabs -->
	<?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'condition')); ?>
		<!-- First tab -->
		<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'condition', JText::_('COM_ORTRANSLATOR_TAB_CONDITION', true)); ?>
			<div class="row-fluid">
				<div class="span9 form-horizontal">
					<fieldset class="adminform">
						<?php echo $this->form->renderField('assignment'); ?>
						<?php echo $this->form->renderField('termino'); ?>
						<?php echo $this->form->renderField('title'); ?>
						<?php echo $this->form->renderField('term'); ?>
					</fieldset>
				</div>
				<div class="span3">
					<?php echo JLayoutHelper::render('joomla.edit.global', $this); ?>
				</div>
			</div>
		<?php echo JHtml::_('bootstrap.endTab'); ?>
		<!-- End of first tab -->

		<!-- Permissions tab -->
		<?php if (JFactory::getUser()->authorise('core.admin','client')) : ?>
			<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'permissions', JText::_('JGLOBAL_ACTION_PERMISSIONS_LABEL', true)); ?>
				<?php echo $this->form->getInput('rules'); ?>
			<?php echo JHtml::_('bootstrap.endTab'); ?>
		<?php endif; ?>
		<!-- End of permissions tab -->
	<?php echo JHtml::_('bootstrap.endTabSet'); ?>
	<!-- End of all tabs -->

	<input type="hidden" name="task" value=""/>
	<?php echo JHtml::_('form.token'); ?>

</form>