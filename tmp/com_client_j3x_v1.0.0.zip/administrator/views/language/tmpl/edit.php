<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;


HTMLHelper::addIncludePath(JPATH_COMPONENT . '/helpers/html');
HTMLHelper::_('behavior.tooltip');
HTMLHelper::_('behavior.formvalidation');
HTMLHelper::_('formbehavior.chosen', 'select');
HTMLHelper::_('behavior.keepalive');

// Import CSS
$document = Factory::getDocument();
$document->addStyleSheet(Uri::root() . 'media/com_client/css/form.css');
?>
<script type="text/javascript">
	js = jQuery.noConflict();
	js(document).ready(function () {

	});

	Joomla.submitbutton = function (task) {
		if (task == 'language.cancel') {
			Joomla.submitform(task, document.getElementById('language-form'));
		}
		else {

			if (task != 'language.cancel' && document.formvalidator.isValid(document.id('language-form'))) {

				Joomla.submitform(task, document.getElementById('language-form'));
			}
			else {
				alert('<?php echo $this->escape(Text::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
			}
		}
	}
</script>

<form
	action="<?php echo JRoute::_('index.php?option=com_client&layout=edit&id=' . (int) $this->item->id); ?>"
	method="post" enctype="multipart/form-data" name="adminForm" id="language-form" class="form-validate form-horizontal">


	<input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
	<input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />
	<input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />
	<input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />
	<input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />
	<?php echo $this->form->renderField('created_by'); ?>
	<?php echo $this->form->renderField('modified_by'); ?>
	<?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'language')); ?>
	<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'language', JText::_('COM_ORTRANSLATOR_TAB_LANGUAGE', true)); ?>
	<div class="row-fluid">
		<div class="span10 form-horizontal">
			<fieldset class="adminform">
				<legend><?php echo JText::_('COM_ORTRANSLATOR_FIELDSET_PROCEDENCIA'); ?></legend>
				<?php echo $this->form->renderField('language_from'); ?>
				<?php echo $this->form->renderField('country_from'); ?>
				<?php echo $this->form->renderField('tag_from'); ?>
			</fieldset>
			<fieldset class="adminform">
				<legend><?php echo JText::_('COM_ORTRANSLATOR_FIELDSET_DESTINO'); ?></legend>
				<?php echo $this->form->renderField('language_to'); ?>
				<?php echo $this->form->renderField('country_to'); ?>
				<?php echo $this->form->renderField('tag_to'); ?>
			</fieldset>
			<fieldset class="adminform">
				<legend><?php echo JText::_('Precios'); ?></legend>
				<?php echo $this->form->renderField('price_1'); ?>
				<?php echo $this->form->renderField('price_2'); ?>
				<?php echo $this->form->renderField('price_3'); ?>

				<?php if ($this->state->params->get('save_history', 1)) : ?>
					<div class="control-group">
						<div class="control-label"><?php // echo $this->form->getLabel('version_note'); ?></div>
						<div class="controls"><?php // echo $this->form->getInput('version_note'); ?></div>
					</div>
				<?php endif; ?>
			</fieldset>
		</div>
	</div>
	<?php echo JHtml::_('bootstrap.endTab'); ?>

	<?php if (JFactory::getUser()->authorise('core.admin','client')) : ?>
	<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'permissions', JText::_('JGLOBAL_ACTION_PERMISSIONS_LABEL', true)); ?>
	<?php echo $this->form->getInput('rules'); ?>
	<?php echo JHtml::_('bootstrap.endTab'); ?>
	<?php endif; ?>
	<?php echo JHtml::_('bootstrap.endTabSet'); ?>
	<?php echo $this->form->renderField('composed_tag'); ?>
	<input type="hidden" name="task" value=""/>
	<?php echo JHtml::_('form.token'); ?>
</form>
<script type="text/javascript">
	var countryFrom = jQuery('#jform_country_from').val();
	var languageFrom = jQuery('#jform_language_from').val();
	var countryTo = jQuery('#jform_country_to').val();
	var languageTo = jQuery('#jform_language_to').val();

	function getLangTagFrom(){
		var tagFrom = getLangTag(countryFrom, languageFrom);
		return tagFrom;
	};
	function getLangTagTo(){
		var tagTo = getLangTag(countryTo, languageTo);
		return tagTo;
	};

	function setComposedTag(){
		var composedTag = getLangTagFrom()+'_'+getLangTagTo();
		jQuery('#jform_composed_tag').val(composedTag);
	}

</script>
