<?php

/**
 * @version    3.2
 * @package    com_client
 * @author     Maikol Fustes <maikol.ortigueira@gmail.com>
 * @copyright  2019 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

// Import TCPDF library
jimport('tcpdf.tcpdf');

require_once JPATH_COMPONENT_SITE  . '/helpers/dompdf/autoload.inc.php';
use Dompdf\Dompdf;

/**
 * Pdf Helper.
 *
 * @since  1.6
 */
abstract class PdfHelper
{

	public static function getPdf($content, $css, $alias)
	{

		$html ='<style type="text/css">';
		$html .=$css;
		$html .='</style>';

		$html .='<div>';
		$html .= $content; //or any other field you like
		$html .='</div>';

		$dompdf = new Dompdf();
		$dompdf->set_option('isHtml5ParserEnabled', true);
		$dompdf->setPaper('A4', 'portrait');
		$dompdf->setBasePath(JPATH_COMPONENT_SITE . '/helpers/dompdf');
		$dompdf->loadHtml($html);
		$dompdf->render();
		$dompdf->output();

		$filename = $alias . '.pdf';

		$dompdf->stream($filename);
	}
}