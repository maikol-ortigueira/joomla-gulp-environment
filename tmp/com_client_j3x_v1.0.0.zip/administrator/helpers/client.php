<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Client
 * @author     Maikol Fustes <maikol@maikol.eu>
 * @copyright  2020 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Component\ComponentHelper;
use \Joomla\CMS\Date\Date;

/**
 * Client helper.
 *
 * @since  1.6
 */
class ClientHelper
{
	/**
	 * Configure the Linkbar.
	 *
	 * @param   string  $vName  string
	 *
	 * @return void
	 */
	public static function addSubmenu($vName = '')
	{
		JHtmlSidebar::addEntry(
			JText::_('COM_ORTRANSLATOR_TITLE_TRANSLATIONS'),
			'index.php?option=com_client&view=translations',
			$vName == 'translations'
		);

		JHtmlSidebar::addEntry(
			JText::_('COM_ORTRANSLATOR_TITLE_INVOICES'),
			'index.php?option=com_client&view=invoices',
			$vName == 'invoices'
		);

		JHtmlSidebar::addEntry(
			JText::_('COM_ORTRANSLATOR_TITLE_QUOTES'),
			'index.php?option=com_client&view=quotes',
			$vName == 'quotes'
		);

		JHtmlSidebar::addEntry(
			JText::_('COM_ORTRANSLATOR_TITLE_CLIENTS'),
			'index.php?option=com_client&view=clients',
			$vName == 'clients'
		);

		JHtmlSidebar::addEntry(
			JText::_('JCATEGORIES') . ' (' . JText::_('COM_ORTRANSLATOR_TITLE_CLIENTS') . ')',
			"index.php?option=com_categories&extension=com_client.clients",
			$vName == 'categories.clients'
		);
		if ($vName=='categories') {
			JToolBarHelper::title('Clientes: JCATEGORIES (COM_ORTRANSLATOR_TITLE_CLIENTS)');
		}

		JHtmlSidebar::addEntry(
			JText::_('COM_ORTRANSLATOR_TITLE_TRANSLATORS'),
			'index.php?option=com_client&view=translators',
			$vName == 'translators'
		);

		JHtmlSidebar::addEntry(
			JText::_('COM_ORTRANSLATOR_TITLE_LANGUAGES'),
			'index.php?option=com_client&view=languages',
			$vName == 'languages'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_ORTRANSLATOR_TITLE_CONDITIONS'),
			'index.php?option=com_client&view=conditions',
			$vName == 'conditions'
		);

		JHtmlSidebar::addEntry(
			JText::_('COM_ORTRANSLATOR_TITLE_EMAIL_TEMPLATES'),
			'index.php?option=com_client&view=email_templates',
			$vName == 'email_templates'
		);

	}

	/**
	 * Gets the files attached to an item
	 *
	 * @param   int     $pk     The item's id
	 *
	 * @param   string  $table  The table's name
	 *
	 * @param   string  $field  The field's name
	 *
	 * @return  array  The files
	 */
	public static function getFiles($pk, $table, $field)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$query
			->select($field)
			->from($table)
			->where('id = ' . (int) $pk);

		$db->setQuery($query);

		return explode(',', $db->loadResult());
	}

	/**
	 * Gets a list of the actions that can be performed.
	 *
	 * @return    JObject
	 *
	 * @since    1.6
	 */
	public static function getActions()
	{
		$user   = Factory::getUser();
		$result = new JObject;

		$assetName = 'com_client';

		$actions = array(
			'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
		);

		foreach ($actions as $action)
		{
			$result->set($action, $user->authorise($action, $assetName));
		}

		return $result;
	}

	/**
	 * Método que devuelve el valor de un campo de la tabla
	 *
	 * @param  [string] $table      [nombre de la tabla #__tabla]
	 * @param  [string] $select     [nombre del campo que contiene el valor]
	 * @param  [string] $whereValue [valor del campo de referencia]
	 * @param  string $whereField [nombre del campo de referencia]
	 * @return [string]             [valor del campo]
	 */
	public static function getFieldValue($table, $select, $whereValue, $whereField = 'id')
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$query
			->select($select)
			->from($table)
			->where($db->quoteName($whereField) . ' = ' . $db->quote($whereValue));

		$db->setQuery($query);

		return $db->loadResult();
	}

	/**
	 * Método que devuelve valores de una tabla de la base de datos
	 *
	 * @param  string $table      Nombre de la tabla #__...
	 * @param  array $select     Campos con los valores buscados
	 * @param  string $whereValue Valor del campo de refencia
	 * @param  string $whereField Nombre del campo de refencia
	 * @return objeto             valores devueltos
	 */
	public static function getFieldValues($table, $select, $whereValue, $whereField = 'id')
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$query
			->select($select)
			->from($table)
			->where($db->quoteName($whereField) . ' = ' . $db->quote($whereValue));


		$db->setQuery($query);

		return $db->loadObjectList();
	}


	/*
	 * Método que devuelve las distintas etiquetas idioma-PAIS desde para los nombres de tabs de traducciones
	 */
	public static function getTraslatebleFrom()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$query->select('DISTINCT tag_from');
		$query->from('#__client_languages');
		$query->group_by('tag_from');

		$db->setQuery($query);

		$return = $db->loadObjectList();

		return $return;
	}

	public static function arrangeTable($table)
	{
		// Si el nombre viene sin prefijo de tabla tipo #__
		if (substr($table, 0, 3) != '#__')
		{
			$table = '#__'.$table;
		}
		// Si el nombre de la tabla contiene punto, la sustituyo por un guión bajo
		$table = str_replace(".", "_", $table);

		return $table;
	}

	public static function formatCurrency($value)
	{
		$params = ComponentHelper::getParams('com_client');
		$currency = $params->get('currency');
		$position = $params->get('currency_position');

		if ($position == 1)
		{
			$value = $value . " " . $currency;
		}
		else
		{
			$value = $currency . " " . $value;
		}

		return $value;
	}

	/**
	 * Método para generar las etiquetas de sustitución para panel de configuración de facturas, presupuestos y proyectos, así como también para su uso en las plantillas de correo electrónico.
	 * @param  array  $data 'view' => 'nombre de la vista en singular'
	 *                      'client_id' => id del cliente.
	 *
	 * @return array       Por un lado una cadena JSON con el índice 'refName' que contiene el prefijo (antes de número) y sufijo (después) de la cadena número de referencia.
	 *                     Por otro lado una cadena de las etiquetas utilizables para su uso con un field type="codetag" donde view='vista en singular'
	 */
	public static function getRefName($data=array())
	{
		// Declarar la variable con los datos de reemplazo
		$replaceValue = array();

		// Que es lo que quiere la configuración global
		// El campo global tendrá el nombre $data['view']_ref_format
		$params = ComponentHelper::getParams('com_client');
		$subject = $params->get($data['view'].'_ref_format');

		// Que variables puede utilizar la configuración global propongo:
		// Generales: {año}{mes}{dia}{hora}{minuto}{id_usuario}{username}{num_cliente}

		// Datos del usuario
		$user = Factory::getUser();
		$userId = $user->id;
		$username = $user->username;

		// Fechas
		$config = Factory::getConfig();
		$offset = $config->get('offset');

		$today = Factory::getDate('now',$offset);
		$year = $today->format('Y');
		$mounth = $today->format('m');
		$day = $today->format('d');
		$hour = $today->format('H', true);
		$minute = $today->format('i');

		// Pasar los datos al array con los datos de reemplazo
		$replaceValue = array('year'=>$year, 'mounth'=>$mounth, 'day'=>$day, 'hour'=>$hour, 'minute'=>$minute, 'userId'=>$userId, 'userName'=>$username);

		// Traducciones: {num_cliente}
		$clientNum = "";

		if (isset($data['client_id']))
		{
			$clientNum = $data['client_id'];
			$replaceValue['clientId'] = $clientNum;
		}

		// Prespuestos: {quoteNum}
		if ($data['view'] == 'quote')
		{
			$quoteNum = "";
			$replaceValue['quoteNum'] = $quoteNum;
			$parte = 'quoteNum';
		}


		// Facturas: {invoiceNum}
		if ($data['view'] == 'invoice')
		{
			$invoiceNum = "";
			$replaceValue['invoiceNum'] = $invoiceNum;
			$parte = 'invoiceNum';
		}

		// Traducciones: {proyectNum}
		if ($data['view'] == 'translation')
		{
			$proyectNum = "";
			$replaceValue['proyectNum'] = $proyectNum;
			$parte = 'proyectNum';
		}


		// Correo electrónico: {nombre_del_traductor}{idioma_de_procedencia}{pais_de_procedencia}{idioma_de_destino}{pais_de_destino}
		if ($data['view'] == 'email_template')
		{
			$proyectNum = "";
			$replaceValue['translatorName'] = $translatorName;
			$replaceValue['languageSource'] = $languageSource;
			$replaceValue['languageTarget'] = $languageTarget;
			$replaceValue['countrySource'] = $countrySource;
			$replaceValue['countryTarget'] = $countryTarget;
		}

		// Preparo los arrays para realizar las sustituciones
		$searchs = array();
		$replaces = array();

		foreach ($replaceValue as $search => $replace) {
			$searchs[] = $search;
			$replaces[] = $replace;
		}

		// Colocar prefijo y sufijo a las cadenas a sustituir
		foreach ($searchs as $i => $v) {
			$searchs[$i] = '/{' . $v . '}/';
			// Preparo las variables que se podrán utilizar para mostrar en la configuración
			$show[$i] = '<code>{' . $v . '}</code>';
		}

		// Comprobamos si el número está dentro de la cadena
		if (isset($parte))
		{
			$numExists = strpos($subject, '{' . $parte . '}');
		}
		else
		{
			$numExists = false;
		}

		// Si no está en la cadena simplemente sustituimos las variables por los valores
		if ($numExists === false)
		{
			$refName['preNum'] = preg_replace($searchs, $replaces, $subject);
			$refName['postNum'] = "";
		}
		else
		{
			// Si está en la cadena partimos por el campo de número
			$subject = explode('{' . $parte . '}', $subject);

			$refName['preNum'] = preg_replace($searchs, $replaces, $subject[0]);
			$refName['postNum'] = preg_replace($searchs, $replaces, $subject[1]);
		}

		// Convierto las variables a mostrar en la configuración en un string
		$show = implode(" ", $show);

		$return['refName'] = json_encode($refName);

		$variables = $data['view'].'_variables';

		$return[$data['view'].'_variables'] = $show;

		return $return;
	}

	public static function fillZeros($name, $zeros, $position = 'izquierda', $string = '0')
	{
		// Relleno a la izquierda o derecha
		$position = ($position == 'izquierda') ? STR_PAD_LEFT : "";

		return str_pad($name, $zeros, '0', $position);
	}

	public static function getProvincia($value)
	{
		$provincias = self::getProvincias();

		return $provincias[$value];
	}

	public static function getPais($value)
	{
		$paises = self::getPaises();

		return $paises[$value];
	}

	public static function getIdioma($value)
	{
		$idiomas = self::getIdiomas();

		return $idiomas[$value];
	}

	public static function getEmailTemplates()
	{
		$emailTemplates = ['send_invoice', 'send_quote', 'send_translated', 'send_to_translate'];

		return $emailTemplates;
	}

	public static function getProvincias()
	{
		 $provincias = ['Alava','Albacete','Alicante','Almería','Asturias','Avila','Badajoz','Barcelona','Burgos','Cáceres','Cádiz','Cantabria','Castellón','Ciudad Real','Córdoba','A Coruña','Cuenca','Gerona','Granada','Guadalajara','Guipúzcoa','Huelva','Huesca','Islas Baleares','Jaén','León','Lérida','Lugo','Madrid','Málaga','Murcia','Navarra','Orense','Palencia','Las Palmas','Pontevedra','La Rioja','Salamanca','Segovia','Sevilla','Soria','Tarragona','Santa Cruz de Tenerife','Teruel','Toledo','Valencia','Valladolid','Vizcaya','Zamora','Zaragoza'];

		 return $provincias;
	}

	public static function getPaises()
	{
		$paises = array(
			"ES"=>"España",
			"DE"=>"Alemania",
			"FR"=>"Francia",
			"IT"=>"Italia",
			"NL"=>"Países Bajos",
			"PT"=>"Portugal",
			"EN"=>"Inglaterra",
			"CH"=>"Suiza",
			"AL"=>"Albania",
			"AD"=>"Andorra",
			"AM"=>"Armenia",
			"AT"=>"Austria",
			"AZ"=>"Azerbaiyán",
			"BE"=>"Bélgica",
			"BY"=>"Bielorrusia",
			"BA"=>"Bosnia y Herzegovina",
			"BG"=>"Bulgaria",
			"CY"=>"Chipre",
			"VA"=>"Ciudad del Vaticano (Santa Sede)",
			"HR"=>"Croacia",
			"DK"=>"Dinamarca",
			"SK"=>"Eslovaquia",
			"SI"=>"Eslovenia",
			"EE"=>"Estonia",
			"FI"=>"Finlandia",
			"GE"=>"Georgia",
			"GR"=>"Grecia",
			"HU"=>"Hungría",
			"IE"=>"Irlanda",
			"IS"=>"Islandia",
			"XK"=>"Kosovo",
			"LV"=>"Letonia",
			"LI"=>"Liechtenstein",
			"LT"=>"Lituania",
			"LU"=>"Luxemburgo",
			"MK"=>"Macedonia, República de",
			"MT"=>"Malta",
			"MD"=>"Moldavia",
			"MC"=>"Mónaco",
			"ME"=>"Montenegro",
			"NO"=>"Noruega",
			"PL"=>"Polonia",
			"CZ"=>"República Checa",
			"RO"=>"Rumanía",
			"RU"=>"Rusia",
			"SM"=>"San Marino",
			"SE"=>"Suecia",
			"TR"=>"Turquía",
			"UA"=>"Ucrania",
			"YU"=>"Yugoslavia",
			"AO"=>"Angola",
			"DZ"=>"Argelia",
			"BJ"=>"Benín",
			"BW"=>"Botswana",
			"BF"=>"Burkina Faso",
			"BI"=>"Burundi",
			"CM"=>"Camerún",
			"CV"=>"Cabo Verde",
			"TD"=>"Chad",
			"KM"=>"Comores",
			"CG"=>"Congo",
			"CD"=>"Congo, República Democrática del",
			"CI"=>"Costa de Marfil",
			"EG"=>"Egipto",
			"ER"=>"Eritrea",
			"ET"=>"Etiopía",
			"GA"=>"Gabón",
			"GM"=>"Gambia",
			"GH"=>"Ghana",
			"GN"=>"Guinea",
			"GW"=>"Guinea Bissau",
			"GQ"=>"Guinea Ecuatorial",
			"KE"=>"Kenia",
			"LS"=>"Lesoto",
			"LR"=>"Liberia",
			"LY"=>"Libia",
			"MG"=>"Madagascar",
			"MW"=>"Malawi",
			"ML"=>"Malí",
			"MA"=>"Marruecos",
			"MU"=>"Mauricio",
			"MR"=>"Mauritania",
			"MZ"=>"Mozambique",
			"NA"=>"Namibia",
			"NE"=>"Níger",
			"NG"=>"Nigeria",
			"CF"=>"República Centroafricana",
			"ZA"=>"República de Sudáfrica",
			"RW"=>"Ruanda",
			"EH"=>"Sahara Occidental",
			"ST"=>"Santo Tomé y Príncipe",
			"SN"=>"Senegal",
			"SC"=>"Seychelles",
			"SL"=>"Sierra Leona",
			"SO"=>"Somalia",
			"SD"=>"Sudán",
			"SS"=>"Sudán del Sur",
			"SZ"=>"Suazilandia",
			"TZ"=>"Tanzania",
			"TG"=>"Togo",
			"TN"=>"Túnez",
			"UG"=>"Uganda",
			"DJ"=>"Yibuti",
			"ZM"=>"Zambia",
			"ZW"=>"Zimbabue",
			"AU"=>"Australia",
			"FM"=>"Micronesia, Estados Federados de",
			"FJ"=>"Fiji",
			"KI"=>"Kiribati",
			"MH"=>"Islas Marshall",
			"SB"=>"Islas Salomón",
			"NR"=>"Nauru",
			"NZ"=>"Nueva Zelanda",
			"PW"=>"Palaos",
			"PG"=>"Papúa Nueva Guinea",
			"WS"=>"Samoa",
			"TO"=>"Tonga",
			"TV"=>"Tuvalu",
			"VU"=>"Vanuatu",
			"AR"=>"Argentina",
			"BO"=>"Bolivia",
			"BR"=>"Brasil",
			"CL"=>"Chile",
			"CO"=>"Colombia",
			"EC"=>"Ecuador",
			"GY"=>"Guayana",
			"PY"=>"Paraguay",
			"PE"=>"Perú",
			"SR"=>"Surinam",
			"TT"=>"Trinidad y Tobago",
			"UY"=>"Uruguay",
			"VE"=>"Venezuela",
			"AG"=>"Antigua y Barbuda",
			"BS"=>"Bahamas",
			"BB"=>"Barbados",
			"BZ"=>"Belice",
			"CA"=>"Canadá",
			"CR"=>"Costa Rica",
			"CU"=>"Cuba",
			"DM"=>"Dominica",
			"SV"=>"El Salvador",
			"US"=>"Estados Unidos",
			"GD"=>"Granada",
			"GT"=>"Guatemala",
			"HT"=>"Haití",
			"HN"=>"Honduras",
			"JM"=>"Jamaica",
			"MX"=>"México",
			"NI"=>"Nicaragua",
			"PA"=>"Panamá",
			"PR"=>"Puerto Rico",
			"DO"=>"República Dominicana",
			"KN"=>"San Cristóbal y Nieves",
			"VC"=>"San Vicente y Granadinas",
			"LC"=>"Santa Lucía",
			"AF"=>"Afganistán",
			"SA"=>"Arabia Saudí",
			"BH"=>"Baréin",
			"BD"=>"Bangladesh",
			"MM"=>"Birmania",
			"BT"=>"Bután",
			"BN"=>"Brunéi",
			"KH"=>"Camboya",
			"CN"=>"China",
			"KP"=>"Corea, República Popular Democrática de",
			"KR"=>"Corea, República de",
			"AE"=>"Emiratos Árabes Unidos",
			"PH"=>"Filipinas",
			"IN"=>"India",
			"ID"=>"Indonesia",
			"IQ"=>"Iraq",
			"IR"=>"Irán",
			"IL"=>"Israel",
			"JP"=>"Japón",
			"JO"=>"Jordania",
			"KZ"=>"Kazajistán",
			"KG"=>"Kirguizistán",
			"KW"=>"Kuwait",
			"LA"=>"Laos",
			"LB"=>"Líbano",
			"MY"=>"Malasia",
			"MV"=>"Maldivas",
			"MN"=>"Mongolia",
			"NP"=>"Nepal",
			"OM"=>"Omán",
			"PK"=>"Paquistán",
			"QA"=>"Qatar",
			"SG"=>"Singapur",
			"SY"=>"Siria",
			"LK"=>"Sri Lanka",
			"TJ"=>"Tayikistán",
			"TH"=>"Tailandia",
			"TP"=>"Timor Oriental",
			"TM"=>"Turkmenistán",
			"UZ"=>"Uzbekistán",
			"VN"=>"Vietnam",
			"YE"=>"Yemen",
		);
		return $paises;
	}

	public static function getIdiomas()
	{
		$idiomas = array(
			"es"=>"Español",
			"en"=>"Inglés",
			"fr"=>"Francés",
			"de"=>"Alemán",
			"eu"=>"Vasco",
			"ca"=>"Catalán",
			"gl"=>"Gallego",
			"pt"=>"Portugués",
			"nl"=>"Holandés",
			"it"=>"Italiano",
			"ja"=>"Japonés",
			"el"=>"Griego Moderno",
			"sq"=>"Albano",
			"ar"=>"Árabe",
			"an"=>"Aragonés",
			"hy"=>"Armenio",
			"az"=>"Azerbaiyán",
			"br"=>"Breton",
			"bg"=>"Búlgaro",
			"ce"=>"Chechenio",
			"zh"=>"Chino",
			"co"=>"Corso",
			"hr"=>"Croata",
			"cs"=>"Checo",
			"da"=>"Danés",
			"eo"=>"Esperanto",
			"et"=>"Estonio",
			"fi"=>"Finlandés",
			"ka"=>"Georgiano",
			"gn"=>"Guaraní",
			"he"=>"Hebreo (moderno)",
			"hi"=>"Hindi",
			"hu"=>"Húngaro",
			"id"=>"Indonesio",
			"is"=>"Islandés",
			"ko"=>"Coreano",
			"ku"=>"Kurdo",
			"la"=>"Latin",
			"lb"=>"Luxemburgués",
			"lt"=>"Lituano",
			"lv"=>"Letón",
			"mk"=>"Macedonio",
			"ms"=>"Malayo",
			"mt"=>"Maltés",
			"mi"=>"Māori",
			"nv"=>"Navajo",
			"nb"=>"Noruego Bokmål",
			"ne"=>"Nepali",
			"nn"=>"Noruego Nynorsk",
			"no"=>"Noruego",
			"fa"=>"Persa",
			"pl"=>"Polaco",
			"rm"=>"Romanche",
			"ro"=>"Rumano",
			"ru"=>"Ruso",
			"sr"=>"Serbio",
			"gd"=>"Gaélico escocés",
			"sk"=>"Eslovaco",
			"sl"=>"Esloveno",
			"so"=>"Somalí",
			"sv"=>"Sueco",
			"th"=>"Tailandés",
			"bo"=>"Tibetano estándar, Tibetano, Central",
			"tl"=>"Tagalo",
			"tr"=>"Turco",
			"uk"=>"Ucraniano",
			"ur"=>"Urdu",
			"uz"=>"Uzbeko",
			"vi"=>"Vietnamita",
			"cy"=>"Galés",
			"zu"=>"Zulu",
		);

		return $idiomas;
	}
}

