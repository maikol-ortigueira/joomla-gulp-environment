<?php
/**
 * @version    3.2
 * @package    com_client
 * @author     Maikol Fustes <maikol.ortigueira@gmail.com>
 * @copyright  2019 Maikol Fustes
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */

//namespace Joomla\Component\Client\Administrator\Helpers;

// No direct access
defined('_JEXEC') or die;


use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Component\ComponentHelper;

/**
 * Email helper
 */
class EmailHelper
{
	public static function sendEmail($emailTo = array(), $sender, $body="", $subject = "", $html = true)
	{
		$mailer = Factory::getMailer();

		$mailer->setSender($sender);

		// Set the recipient
		$mailer->addRecipient($emailTo);

		// Set the subject
		$mailer->setSubject($subject);

		// Set the body
		$mailer->setBody($body);

		// If body in HTML
		if ($html) {
			$mailer->isHtml(true);
			$mailer->Encoding = 'base64';
		}

		$send = $mailer->Send();

		if ($send !== true)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	public static function getEmailContentFixed($subject, $data)
	{
		$patterns = array();
		$replacements = array();

		foreach ($data as $pattern => $replacement) {
			$patterns[] = $pattern;
			$replacements[] = $replacement;
		}

		// add prefix and suffix to each string
		foreach ($patterns as $index=>$one_pattern) {
			$patterns[$index] = '/{'.$one_pattern.'}/';
		}

		$context = preg_replace($patterns, $replacements, $subject);

		return $context;
	}

	public static function getEmailsToData($ids, $table)
	{
		// Recuperar los datos de la base de datos
		$emailsToData = ClientHelper::getFieldValues($table, '*', $ids, $whereField = 'id');

		// Devolver los datos
		return $emailsToData;
	}

	public static function getEmailsTo($ids, $table)
	{
		$emailsToData = self::getEmailsToData($ids, $table);

		$emails = array();
		// Arreglar los datos
		foreach ($emailsToData as $emailToData)
		{
			// Si los datos pertenecen a un cliente debemos seleccionar la dirección de envío según deseo del cliente
			if ($table === '#__clients')
			{
				if ($emailToData->inv_other == 0)
				{
					$emails[] = $emailToData->inv_email;
				}
				else
				{
					$emails[] = $emailToData->email;
				}
			}

			// Buscamos la dirección de envío en función de la configuración de los datos del traductor
			if ($table === '#__client_translators')
			{
				if ($emailToData->send_translations_to == 1)
				{
					$emails[] = $emailToData->contacte_mail;
				}
				else
				{
					$emails[] = $emailToData->email;
				}
			}
		}
		return $emails;
	}

	/**
	 * Método que devuelve el contenido de la plantilla.
	 * @param  string $name Nombre de la plantilla. Ej.: 'sent_to_translate'
	 * @return string       Contenido de la plantilla.
	 */
	public static function getEmailTemplate($name)
	{
		$template_title = array_search($name, ClientHelper::getEmailTemplates());

		$emailTemplate = ClientHelper::getFieldValue('#__client_email_templates', 'email_content', $template_title, 'title');

		return $emailTemplate;
	}

	public static function getToTranslateEmailData($data)
	{
		$emailData = array();

		$table = ClientHelper::arrangeTable($data['table']);
		// Recuperamos todos los datos de las personas a las que enviaremos el correo
		$emailsToData = self::getEmailsToData($data['email_to'], $table);
		$emailsToData = $emailsToData[0];

		// Recuperamos las direcciones de correo a las que se enviará el mensaje
		$emailData['emailsTo'] = self::getEmailsTo($data['email_to'], $table);

		// Recupermos el contenido de la plantilla
		$emailContent = self::getEmailTemplate($data['email_template']);

		// Preparamos los datos a sustituir
		// Recuperamos los datos de los idiomas de y para
		$languages = ClientHelper::getFieldValues('#__client_languages', array('language_from', 'country_from', 'language_to', 'country_to'), $data['language'], $whereField = 'id');

		$replaceData['nombre_del_traductor'] = $emailsToData->name;
		$replaceData['idioma_de_procedencia'] = ClientHelper::getIdioma($languages[0]->language_from);
		$replaceData['pais_de_procedencia'] = ClientHelper::getPais($languages[0]->country_from);
		$replaceData['idioma_de_destino'] = ClientHelper::getIdioma($languages[0]->language_to);
		$replaceData['pais_de_destino'] = ClientHelper::getPais($languages[0]->country_to);

		// Preparamos el contenido del correo
		$emailData['body'] = EmailHelper::getEmailContentFixed($emailContent, $replaceData);

		return $emailData;
	}
}